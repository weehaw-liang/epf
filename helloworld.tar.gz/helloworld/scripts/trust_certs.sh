for filename in /certs/* ; do
	[ -e "$filename" ] || continue
	echo $filename
	tempalias=$(mktemp -u | grep -o -P '(?<=tmp\.).*')
	keytool -noprompt -import -alias kwsp_$tempalias -keystore /usr/local/openjdk-11/lib/security/cacerts -storepass changeit -file $filename
	echo "trusted $filename as alias kwsp_$tempalias" >> /tmp/trust_certs.log
done
