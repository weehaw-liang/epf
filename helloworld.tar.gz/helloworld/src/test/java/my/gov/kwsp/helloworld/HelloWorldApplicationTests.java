package my.gov.kwsp.helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.web.servlet.error.ErrorMvcAutoConfiguration;

@SpringBootApplication(exclude = { ErrorMvcAutoConfiguration.class, DataSourceAutoConfiguration.class })
@EnableAutoConfiguration
public class HelloWorldApplicationTests {

	public static void main(String[] args) {
		SpringApplication.run(HelloWorldApplicationTests.class, args);
		
	}
}
