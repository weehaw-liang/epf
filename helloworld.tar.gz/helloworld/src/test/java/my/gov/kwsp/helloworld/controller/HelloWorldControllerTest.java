package my.gov.kwsp.helloworld.controller;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.Import;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

import my.gov.kwsp.helloworld.HelloWorldApplication;
import my.gov.kwsp.helloworld.common.config.PropertyConfiguration;
import my.gov.kwsp.helloworld.controllers.HelloWorldController;

@ActiveProfiles("test")
@EnableAutoConfiguration
@EnableEncryptableProperties
@Import(PropertyConfiguration.class)
@AutoConfigureMockMvc
@ContextConfiguration(classes = { HelloWorldControllerTest.class, HelloWorldController.class,
		HelloWorldApplication.class })
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class HelloWorldControllerTest {

	@Autowired
	private TestRestTemplate template;

	@Test
	public void getHello_ok() throws Exception {
		ResponseEntity<String> response = template.getForEntity("/api/hello", String.class);

		System.out.println(response.getBody());
		assertThat(response.getBody()).isEqualTo("Hello World, Spring Boot!");
		// assertThat(response.getBody()).isEqualTo("");
		// assertThat(response.getStatusCode().equals(HttpStatus.FORBIDDEN));
	}
}
