package my.gov.kwsp.helloworld.bean;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

public class HelloBean {

	@NotNull
	private String name;

	@NotNull
	@Range(min = 18, max = 55, message = "INVALID_AGE")
	private Integer age;

}