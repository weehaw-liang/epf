package my.gov.kwsp.helloworld.common.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import my.gov.kwsp.helloworld.common.constant.GlobalConstants;
import my.gov.kwsp.helloworld.common.repository.LocaleRepo;

public class BaseAuthorizationFilter extends OncePerRequestFilter {
//public class BaseAuthorizationFilter implements Filter {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseAuthorizationFilter.class);

	private String contentType;
	private String appLang;
	private String appPlatform;
	private String requestTime;
	private String accessToken;

	private String authorization;

	private String activeProfile;
	private String contextPath;
	private String basicAuthUsername;
	private String basicAuthPassword;
	private LocaleRepo localeRepo;

	private static final String EXCEPTION = "Exception";

	private static final List<String> LANG_LIST = List.of("EN", "MS");

	private static final List<String> PLATFORM_LIST = List.of("IOS", "WEB", "ANDROID", "SYSTEM");

	@Autowired
	public BaseAuthorizationFilter(String activeProfile, String contextPath, String basicAuthUsername,
			String basicAuthPassword, LocaleRepo localeRepo) {
		this.activeProfile = activeProfile;
		this.contextPath = contextPath;
		this.basicAuthUsername = basicAuthUsername;
		this.basicAuthPassword = basicAuthPassword;
		this.localeRepo = localeRepo;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
//		MDC.put("session_id", "");
//		MDC.put("epf_no", "");

		LOGGER.info("doFilterInternal started.");

//		request.getSession().setMaxInactiveInterval(120); // 120 second timeout
//
//		MDC.put("session_id", request.getSession().getId());

		try {
//			setUpSpringAuthentication(request);
//
			filterChain.doFilter(request, response);

		} catch (Exception e) {

			LOGGER.error("doFilterInternal: {}", e.toString());

			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			return;
		}

		LOGGER.info("doFilterInternal ended.");
	}

	/**
	 * Authentication method in Spring flow
	 * 
	 * @param session_token
	 */
	private void setUpSpringAuthentication(HttpServletRequest request) {
		String accessToken = request.getHeader(GlobalConstants.ACCESS_TOKEN);

		UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(accessToken, null,
				new ArrayList<>());
		SecurityContextHolder.getContext().setAuthentication(auth);
	}

	@Override
	public void destroy() {
		super.destroy();
	}
}
