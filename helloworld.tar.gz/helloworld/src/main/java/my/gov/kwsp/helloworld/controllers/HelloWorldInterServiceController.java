package my.gov.kwsp.helloworld.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import my.gov.kwsp.helloworld.common.service.LocaleService;
import my.gov.kwsp.helloworld.common.util.BaseUtil;

@RestController
@RequestMapping(value = { "interservice/api/", "/interservice/api" })
public class HelloWorldInterServiceController extends BaseUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldController.class);

	public HelloWorldInterServiceController(LocaleService localeService) {
		super(localeService);
	}

	@ApiOperation(value = "Hello InterService")
	@GetMapping(value = "/helloInterService", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHello() {
		return "Hello World, Spring Boot!";
	}

}
