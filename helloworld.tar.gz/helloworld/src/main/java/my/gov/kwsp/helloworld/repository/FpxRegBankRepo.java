package my.gov.kwsp.helloworld.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import my.gov.kwsp.helloworld.entity.FpxRegBank;

@Repository
public interface FpxRegBankRepo extends JpaRepository<FpxRegBank, Long> {

	@Query("select b from FpxRegBank b " + " where b.bankCode = :bankCode " + " and b.deleted <> 1 ")
	FpxRegBank findByBankCode(@Param("bankCode") String bankCode);

	@Query("select b from FpxRegBank b " + " where b.bankCode in (:bankCodeList) " + " and b.deleted <> 1 "
			+ " order by b.sort asc, b.bankDisplayName asc ")
	List<FpxRegBank> findListByBankCodeListOrderBySortAsc(@Param("bankCodeList") List<String> bankCodeList);

}
