//package my.gov.kwsp.helloworld.common.hazelcast.impl;
//
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import com.hazelcast.config.Config;
//import com.hazelcast.config.MapConfig;
//import com.hazelcast.config.SerializerConfig;
//import com.hazelcast.core.Hazelcast;
//import com.hazelcast.core.HazelcastInstance;
//import com.hazelcast.map.IMap;
//
//import my.gov.kwsp.helloworld.common.exception.ExceptionCode;
//import my.gov.kwsp.helloworld.common.hazelcast.HazelcastMemberProfileService;
//import my.gov.kwsp.helloworld.common.hazelcast.Serializer.MemberProfileSerializer;
//import my.gov.kwsp.helloworld.common.hazelcast.bean.MemberProfile;
//import my.gov.kwsp.helloworld.common.util.DateUtil;
//
//@Service
//public class HazelcastMemberProfileServiceImpl implements HazelcastMemberProfileService {
//
//	private static final Logger LOGGER = LoggerFactory.getLogger(HazelcastMemberProfileServiceImpl.class);
//
//	@Value("${hazelcast.multicast.config}")
//	private boolean multicastConfig;
//
//	@Value("${hazelcast.kubernetes.config}")
//	private boolean kubernetesConfig;
//
//	@Value("${hazelcast.group.name}")
//	private String groupName;
//
//	@Value("${hazelcast.service.name}")
//	private String serviceName;
//
//	@Value("${hazelcast.namespace}")
//	private String nameSpace;
//
//	@Value("${configMap.authorizations.hazelcast.timeToLiveInSeconds}")
//	private int timeToLiveInSeconds;
//
//	@Value("${configMap.authorizations.hazelcast.idleTimeInSeconds}")
//	private int idleTimeInSeconds;
//
//	public static final String MEMBERS = "membersProfile";
//
//	@Autowired
//	private HazelcastInstance client = Hazelcast.newHazelcastInstance(createConfig());
//
//	@Override
//	public MemberProfile put(String key, MemberProfile memberProfile) {
//		IMap<String, MemberProfile> map = client.getMap(MEMBERS);
//
//		try {
//			MemberProfile result = map.put(key, memberProfile);
//			return result;
//		} catch (Exception ex) {
//			ex.printStackTrace();
//
//		}
//		return null;
//	}
//
//	@Override
//	public MemberProfile get(String key) {
//		IMap<String, MemberProfile> map = client.getMap(MEMBERS);
//		return map.get(key);
//	}
//
//	@Override
//	public MemberProfile clear(String key) {
//		IMap<String, MemberProfile> map = client.getMap(MEMBERS);
//		return map.remove(key);
//	}
//
//	public Config createConfig() {
//		Config config = new Config();
//
//		LOGGER.info("multicastConfig b4 hardcode: {}", this.multicastConfig);
//		LOGGER.info("kubernetesConfig b4 hardcode: {}", this.kubernetesConfig);
//
//		kubernetesConfig = true;
//
//		LOGGER.info("multicastConfig: {}", multicastConfig);
//		LOGGER.info("kubernetesConfig: {}", kubernetesConfig);
//
//		config.getNetworkConfig().getJoin().getMulticastConfig().setEnabled(multicastConfig)
//				.setMulticastGroup("hazelcast").setMulticastPort(5701);
//
//		LOGGER.info("service-name b4 hardcode: {}", this.serviceName);
//		LOGGER.info("namespace b4 hardcode: {}", this.nameSpace);
//
//		serviceName = "hazelcast";
//		nameSpace = "iakaun-dev";
//
//		LOGGER.info("service-name: {}", serviceName);
//		LOGGER.info("namespace: {}", nameSpace);
//
//		final String serviceDns = serviceName + "." + nameSpace + ".svc.cluster.local";
//		LOGGER.info("service-dns: {}", serviceDns);
//
//		config.getNetworkConfig().getJoin().getKubernetesConfig().setEnabled(kubernetesConfig)
//				.setProperty("service-dns", serviceDns).setProperty("namespace", nameSpace);
//
//		config.getNetworkConfig().setPort(5701).setPortAutoIncrement(true).setPortCount(20);
//
//		config.setClusterName("hazelcast");
//
//		config.addMapConfig(mapConfig());
//		config.getSerializationConfig().addSerializerConfig(serializerConfig());
//		return config;
//	}
//
//	private SerializerConfig serializerConfig() {
//		return new SerializerConfig().setImplementation(new MemberProfileSerializer())
//				.setTypeClass(MemberProfile.class);
//	}
//
//	private MapConfig mapConfig() {
//
//		LOGGER.info("timeToLiveInSeconds: {}", timeToLiveInSeconds);
//		LOGGER.info("idleTimeInSeconds: {}", idleTimeInSeconds);
//
//		MapConfig mapConfig = new MapConfig(MEMBERS);
//		mapConfig.setTimeToLiveSeconds(timeToLiveInSeconds);
//		mapConfig.setMaxIdleSeconds(idleTimeInSeconds);
//		return mapConfig;
//	}
//
//	@Override
//	public void clearByEpfNo(String key) {
//		MemberProfile memberProfile = get(key);
//
//		if (memberProfile != null) {
//			clear(memberProfile.getAccessToken());
//			clear(memberProfile.getRefreshToken());
//		}
//
//	}
//
//	@Override
//	public Map<String, Object> getByAccessToken(String key) {
//		MemberProfile memberProfile = get(key);
//
//		if (memberProfile != null && (memberProfile.getAccessToken().equals(key))) {
//			Date now = DateUtil.getCurrentDefaultDateTime();
//			Date expiryDate = DateUtil.convertStringToDate(memberProfile.getAccessTokenExpiryTime(),
//					DateUtil.yyyy_MM_dd_HH_mm_ss_SSS);
//
//			if (now.compareTo(expiryDate) >= 0) {
//				clear(key);
//				clear(memberProfile.getAccessToken());
//
//				return mapStatusData(ExceptionCode.ACCESS_TOKEN_EXPIRED, null);
//			} else {
//				return mapStatusData(ExceptionCode.NO_ERROR, memberProfile);
//			}
//
//		}
//
//		return mapStatusData(ExceptionCode.INVALID_ACCESS_TOKEN, null);
//	}
//
//	private Map<String, Object> mapStatusData(ExceptionCode code, MemberProfile profile) {
//
//		Map<String, Object> result = new HashMap<>();
//		result.put("status", code);
//		result.put("data", profile);
//		return result;
//	}
//
//	@Override
//	public Map<String, Object> getByRefreshToken(String key) {
//		MemberProfile memberProfile = get(key);
//
//		if (memberProfile != null && (memberProfile.getRefreshToken().equals(key))) {
//			Date now = DateUtil.getCurrentDefaultDateTime();
//			Date expiryDate = DateUtil.convertStringToDate(memberProfile.getRefreshTokenExpiryTime(),
//					DateUtil.yyyy_MM_dd_HH_mm_ss_SSS);
//
//			if (now.compareTo(expiryDate) >= 0) {
//				clear(key);
//				clear(memberProfile.getAccessToken());
//
//				return mapStatusData(ExceptionCode.REFRESH_TOKEN_EXPIRED, null);
//			} else {
//				return mapStatusData(ExceptionCode.NO_ERROR, memberProfile);
//			}
//
//		}
//
//		return mapStatusData(ExceptionCode.INVALID_REFRESH_TOKEN, null);
//	}
//
//}
