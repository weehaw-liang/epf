package my.gov.kwsp.helloworld.common.hazelcast;

public interface BaseHazelcastService<K, T> {

	public T put(K key, T object);

	public T get(K key);

	public T clear(K key);

}
