package my.gov.kwsp.helloworld.common.bean.esb;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonMemberDetailRes {

	public CommonMemberDetailRes(String name, String epfNo, String myKadNo, String passportNo, String birthDate,
			String gender, String race, String religion, String membershipStartDate, String accountClassification,
			String accountClassificationEffectiveDate, String nationality, String residentStatus,
			String schemeMembership) {
		super();
		this.name = name;
		this.epfNo = epfNo;
		this.myKadNo = myKadNo;
		this.passportNo = passportNo;
		this.birthDate = birthDate;
		this.gender = gender;
		this.race = race;
		this.religion = religion;
		this.membershipStartDate = membershipStartDate;
		this.accountClassification = accountClassification;
		this.accountClassificationEffectiveDate = accountClassificationEffectiveDate;
		this.nationality = nationality;
		this.residentStatus = residentStatus;
		this.schemeMembership = schemeMembership;
	}

	private String name;
	private String epfNo;
	private String myKadNo;
	private String passportNo;
	private String birthDate;
	private String gender;
	private String race;
	private String religion;
	private String membershipStartDate;
	private String accountClassification;
	private String accountClassificationEffectiveDate;
	private String nationality;
	private String residentStatus;
	private String schemeMembership;

	public CommonMemberDetailRes() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEpfNo() {
		return epfNo;
	}

	public void setEpfNo(String epfNo) {
		this.epfNo = epfNo;
	}

	public String getMyKadNo() {
		return myKadNo;
	}

	public void setMyKadNo(String myKadNo) {
		this.myKadNo = myKadNo;
	}

	public String getPassportNo() {
		return passportNo;
	}

	public void setPassportNo(String passportNo) {
		this.passportNo = passportNo;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getMembershipStartDate() {
		return membershipStartDate;
	}

	public void setMembershipStartDate(String membershipStartDate) {
		this.membershipStartDate = membershipStartDate;
	}

	public String getAccountClassification() {
		return accountClassification;
	}

	public void setAccountClassification(String accountClassification) {
		this.accountClassification = accountClassification;
	}

	public String getAccountClassificationEffectiveDate() {
		return accountClassificationEffectiveDate;
	}

	public void setAccountClassificationEffectiveDate(String accountClassificationEffectiveDate) {
		if (accountClassificationEffectiveDate == null || accountClassificationEffectiveDate == "") {
			this.accountClassificationEffectiveDate = membershipStartDate;
		} else {
			this.accountClassificationEffectiveDate = accountClassificationEffectiveDate;
		}
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getResidentStatus() {
		return residentStatus;
	}

	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}

	public String getSchemeMembership() {
		return schemeMembership;
	}

	public void setSchemeMembership(String schemeMembership) {
		this.schemeMembership = schemeMembership;
	}

}