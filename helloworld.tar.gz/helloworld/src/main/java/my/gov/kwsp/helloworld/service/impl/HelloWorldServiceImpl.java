package my.gov.kwsp.helloworld.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import my.gov.kwsp.helloworld.bean.MemberInfoReqBean;
import my.gov.kwsp.helloworld.common.bean.BaseResponse;
import my.gov.kwsp.helloworld.common.bean.EsbMemberResBean;
import my.gov.kwsp.helloworld.common.bean.esb.CommonMemberDetailRes;
import my.gov.kwsp.helloworld.common.exception.ExceptionCode;
import my.gov.kwsp.helloworld.common.service.SequenceNumberService;
import my.gov.kwsp.helloworld.common.service.mapper.MemberDetailMapper;
import my.gov.kwsp.helloworld.common.util.PostEsbUtils;
import my.gov.kwsp.helloworld.entity.FpxRegBank;
import my.gov.kwsp.helloworld.repository.FpxRegBankRepo;
import my.gov.kwsp.helloworld.service.HelloWorldService;

@Service
public class HelloWorldServiceImpl implements HelloWorldService {

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldServiceImpl.class);

	@Autowired
	private FpxRegBankRepo fpxRegBankRepo;

	@Autowired
	MemberDetailMapper memberDetailMapper;

	@Autowired
	private SequenceNumberService sequenceNumberService;

	@Value("${mip.epf-esb.getMemberDetail.url}")
	private String getMemberDetailUrl;

	@Value("${mip.epf-esb.postMemberContactInfo.url}")
	private String postMemberContactInfoUrl;

	@Value("${mip.epf-esb.postMemberAddressInfo.url}")
	private String postMemberAddressInfoUrl;

	@Value("${mip.epf-esb.basic-auth}")
	private String esbBasicAuth;

	@Value("${mip.epf-esb.applIdMemberDetail}")
	private String applIdMemberDetail;

	@Override
	public BaseResponse getFPXBankList() {
		LOGGER.info("getFPXBankList called.");

		BaseResponse baseResponse = new BaseResponse();

		List<FpxRegBank> fpxRegBank = fpxRegBankRepo.findAll();

		LOGGER.info("getFPXBankList.fpxRegBank: {}", fpxRegBank);

		baseResponse = new BaseResponse(ExceptionCode.NO_ERROR);
		baseResponse.setResultStatus("S");
		baseResponse.setResultMessage("Success");
		baseResponse.addData("bankList", fpxRegBank);

		return baseResponse;
	}

	@Override
	public BaseResponse getMemberDetails(MemberInfoReqBean requestBody) {

		BaseResponse baseResponse = new BaseResponse();
		String esbTransCode = "COM00002";

		try {

			PostEsbUtils peu = new PostEsbUtils(sequenceNumberService, esbBasicAuth, applIdMemberDetail, esbTransCode,
					requestBody.getId(), requestBody.getIdType(), requestBody.getEpfNo(), "S", "M", "A", "");
			peu.sendPostGetMemberDetails(getMemberDetailUrl);

			EsbMemberResBean bean = peu.getEsbMemberResBean();

			if (bean != null) {
				CommonMemberDetailRes memberDetailRes = memberDetailMapper.getMemberDetail(bean);

				baseResponse = new BaseResponse(ExceptionCode.NO_ERROR);
				baseResponse.setResultMessage("Success");
				baseResponse.setResultStatus("S");
				baseResponse.addData("memberDetail", memberDetailRes);

			} else {
				baseResponse = new BaseResponse(ExceptionCode.RECORD_NOT_FOUND);
				baseResponse.setResultMessage("Failed.");
				baseResponse.setResultStatus("F");
				return baseResponse;
			}

		} catch (Exception ex) {
			LOGGER.error("getMemberDetails hit error: {}", ex);

			baseResponse = new BaseResponse(ExceptionCode.UNKNOWN_ERROR);
			baseResponse.setResultMessage("fail");
			baseResponse.setResultStatus("F");

			return baseResponse;
		}

		return baseResponse;
	}

}
