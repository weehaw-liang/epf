package my.gov.kwsp.helloworld.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidateAccessTokenReqBean {

	@ApiModelProperty(notes = "serviceURL", example = "", required = true)
//	@NotNull(groups = { FirstValidation.class })
//	@NotEmpty(groups = { FirstValidation.class })
	private String serviceURL;

	private String accessToken;

}
