package my.gov.kwsp.helloworld.controllers;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import my.gov.kwsp.helloworld.common.service.LocaleService;
import my.gov.kwsp.helloworld.common.util.BaseUtil;

@RestController
@RequestMapping(value = { "wla/api/", "/wla/api" })
public class HelloWorldWlaController extends BaseUtil {

	public HelloWorldWlaController(LocaleService localeService) {
		super(localeService);
	}

	@ApiOperation(value = "Hello")
	@GetMapping(value = "/v1/helloWla", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHello() {
		return "Hello World, Spring Boot!";
	}

}
