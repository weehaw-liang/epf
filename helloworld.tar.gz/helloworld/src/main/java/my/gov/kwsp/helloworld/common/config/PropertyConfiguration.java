package my.gov.kwsp.helloworld.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.stereotype.Component;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

/**
 * Loads properties
 */
@Component
@EnableEncryptableProperties
@PropertySources({ @PropertySource(value = "classpath:config.properties", ignoreResourceNotFound = true),
		@PropertySource(value = "file:config.properties", ignoreResourceNotFound = true),
		@PropertySource(value = "file:${external.prop}config.properties", ignoreResourceNotFound = true), })
public class PropertyConfiguration {
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {

		return new PropertySourcesPlaceholderConfigurer();
	}
}
