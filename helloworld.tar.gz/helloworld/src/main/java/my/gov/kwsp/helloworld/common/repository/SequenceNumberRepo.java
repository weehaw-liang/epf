package my.gov.kwsp.helloworld.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import my.gov.kwsp.helloworld.common.entity.SequenceNumber;

@Repository
public interface SequenceNumberRepo extends JpaRepository<SequenceNumber, Long> {

	@Query("select s from SequenceNumber s " + " where s.seqCode = :seqCode ")
	SequenceNumber findBySeqCode(@Param("seqCode") String seqCode);

}
