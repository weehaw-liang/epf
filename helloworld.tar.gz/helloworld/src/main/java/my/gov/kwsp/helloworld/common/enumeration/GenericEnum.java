package my.gov.kwsp.helloworld.common.enumeration;

public interface GenericEnum {

	String getCode();

	String getDescription();
}
