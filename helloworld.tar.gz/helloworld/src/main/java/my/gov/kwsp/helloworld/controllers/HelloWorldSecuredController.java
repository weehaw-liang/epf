package my.gov.kwsp.helloworld.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import my.gov.kwsp.helloworld.bean.HelloBean;
import my.gov.kwsp.helloworld.bean.MemberInfoReqBean;
import my.gov.kwsp.helloworld.common.bean.BaseResponse;
import my.gov.kwsp.helloworld.common.exception.ExceptionCode;
import my.gov.kwsp.helloworld.common.service.LocaleService;
import my.gov.kwsp.helloworld.common.util.BaseUtil;
import my.gov.kwsp.helloworld.service.HelloWorldService;

@RestController
@RequestMapping(value = { "api/secured/", "/api/secured" })
public class HelloWorldSecuredController extends BaseUtil {

	@Autowired
	private HelloWorldService helloWorldService;

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldSecuredController.class);

	public HelloWorldSecuredController(LocaleService localeService) {
		super(localeService);
	}

	@ApiOperation(value = "helloWorldSecured")
	@GetMapping(value = "/v1/helloFilter", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHello() {
		return "Hello World, Spring Boot!";
	}

	@ApiOperation(value = "helloFilter")
	@GetMapping(value = "/v2/helloFilter", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> getHelloFilter(HttpServletRequest request) {

		BaseResponse response = new BaseResponse();

		response = new BaseResponse(ExceptionCode.NO_ERROR);
		response.setResultStatus("S");
		response.setResultMessage("Success");
		HttpStatus status = HttpStatus.OK;

		return ResponseEntity.status(status).body(response);
	}

	@ApiOperation(value = "filterWithSQL")
	@GetMapping(value = "/v1/filterWithSQL", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> getNoFilterSQL(HttpServletRequest request) {

		BaseResponse response = new BaseResponse();

		response = helloWorldService.getFPXBankList();
		HttpStatus status = HttpStatus.OK;

		return ResponseEntity.status(status).body(response);
	}

	@ApiOperation(value = "filterWithESB")
	@PostMapping(value = "/v1/filterWithESB", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> getNoFilterESB(HttpServletRequest request,
			@Valid @RequestBody MemberInfoReqBean requestBody, Errors errors) {

		BaseResponse response = new BaseResponse();

		response = helloWorldService.getMemberDetails(requestBody);
		HttpStatus status = HttpStatus.OK;

		return ResponseEntity.status(status).body(response);
	}

	@PostMapping(value = "/v1/helloAdd", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> addHello(@Valid @RequestBody(required = true) HelloBean reqBean) {
		return ResponseEntity.status(HttpStatus.OK).body(new BaseResponse(ExceptionCode.NO_ERROR));
	}
}
