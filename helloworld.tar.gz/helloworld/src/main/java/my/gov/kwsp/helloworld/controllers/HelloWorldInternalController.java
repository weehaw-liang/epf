package my.gov.kwsp.helloworld.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import my.gov.kwsp.helloworld.common.service.LocaleService;
import my.gov.kwsp.helloworld.common.util.BaseUtil;

@RestController
@RequestMapping(value = { "internal/api/", "/internal/api" })
public class HelloWorldInternalController extends BaseUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldInternalController.class);

	public HelloWorldInternalController(LocaleService localeService) {
		super(localeService);
	}

	@ApiOperation(value = "Hello Internal")
	@GetMapping(value = "/helloInternal", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHello() {
		return "Hello World, Spring Boot!";
	}

}
