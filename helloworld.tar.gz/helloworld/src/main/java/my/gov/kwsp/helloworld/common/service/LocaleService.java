package my.gov.kwsp.helloworld.common.service;

import org.springframework.stereotype.Component;

@Component
public interface LocaleService {

	public String getMessage(String lang, String code);
}
