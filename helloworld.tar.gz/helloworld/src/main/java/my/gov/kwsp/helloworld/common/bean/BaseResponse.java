package my.gov.kwsp.helloworld.common.bean;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

import my.gov.kwsp.helloworld.common.exception.ExceptionCode;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class BaseResponse {

	private String resultCode;
	private String resultMessage;
	private String resultStatus;

	private Map<String, Object> data;

	public BaseResponse() {
	}

	public BaseResponse(ExceptionCode ec) {
		this(ec.code(), ec.description(), ec.status(), new LinkedHashMap<>());
	}

	public BaseResponse(String resultCode, String resultMessage) {
		this(resultCode, resultMessage, new LinkedHashMap<>());
	}

	public BaseResponse(String resultCode, String resultMessage, String resultStatus, Map<String, Object> data) {
		this.resultCode = resultCode;
		this.resultStatus = resultStatus;
		if (!resultCode.equals(ExceptionCode.NO_ERROR.code())) {
			this.resultMessage = resultMessage;
		}
		this.data = data;
	}

	public BaseResponse(String resultCode, String resultMessage, Map<String, Object> data) {
		this.resultCode = resultCode;
		if (!resultCode.equals(ExceptionCode.NO_ERROR.code())) {
			this.resultMessage = resultMessage;
		}
		this.data = data;
	}

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

	public String getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(String resultStatus) {
		this.resultStatus = resultStatus;
	}

	public Map<String, Object> getData() {
		return data;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}

	public Object addData(String key, Object value) {
		if (this.data == null) {
			this.data = new HashMap<>();
		}

		return data.put(key, value);
	}
}
