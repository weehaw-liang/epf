package my.gov.kwsp.helloworld.common.config;

import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.CharacterEncodingFilter;

import my.gov.kwsp.helloworld.common.filter.BaseAuthorizationFilter;
import my.gov.kwsp.helloworld.common.repository.LocaleRepo;
import my.gov.kwsp.helloworld.common.service.ValidateTokenService;

@Profile({ "local", "dev", "test", "uat", "perf", "stag", "prod" })
@Configuration
@EnableWebSecurity
@Component
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Value("${spring.profiles.active}")
	private String activeProfile;

	@Value("${server.servlet.context-path}")
	private String contextPath;

	@Value("${iakaun.epf.postHeartBeat.url}")
	private String epfPostHeartBeatUrl;

	@Value("${spring.basic-auth.username}")
	private String username;

	@Value("${spring.basic-auth.password}")
	private String password;

	@Autowired
	private LocaleRepo localeRepo;

	@Autowired
	private ValidateTokenService validateTokenService;

	@Override
	public void configure(HttpSecurity http) throws Exception {

		CharacterEncodingFilter filter = new CharacterEncodingFilter();
		filter.setEncoding(StandardCharsets.UTF_8.name());
		filter.setForceEncoding(true);

		// session management
		// http.anonymous().disable().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
		// .csrf().disable();

		// disable Cookies & CSRF protection (auth checking will be done in base auth)
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and().csrf().disable();

		// filter
		http.httpBasic()
				// .cors()
				.and().authorizeRequests().antMatchers("/forms/**", "/api/**").permitAll()
				.antMatchers("/**/*.css", "/**/*.js", "/**/*.jpg", "/**/*.png").permitAll().anyRequest().authenticated()
				.and().addFilterBefore(filter, CsrfFilter.class).addFilterBefore(
						new BaseAuthorizationFilter(activeProfile, contextPath, username, password, localeRepo),
						BasicAuthenticationFilter.class);
	}
}
