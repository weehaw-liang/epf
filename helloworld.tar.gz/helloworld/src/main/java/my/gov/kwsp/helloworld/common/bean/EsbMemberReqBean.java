package my.gov.kwsp.helloworld.common.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import my.gov.kwsp.helloworld.common.bean.esb.CommonMemberRequest;
import my.gov.kwsp.helloworld.common.bean.esb.CommonMessageHeader;


@JsonIgnoreProperties(ignoreUnknown = true)
public class EsbMemberReqBean {

	private CommonMessageHeader header;
	private CommonMemberRequest request;

	public EsbMemberReqBean() {
	}

	public CommonMessageHeader getHeader() {
		return header;
	}

	public void setHeader(CommonMessageHeader header) {
		this.header = header;
	}

	public CommonMemberRequest getRequest() {
		return request;
	}

	public void setRequest(CommonMemberRequest request) {
		this.request = request;
	}
}