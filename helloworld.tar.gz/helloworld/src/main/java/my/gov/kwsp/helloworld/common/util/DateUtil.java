package my.gov.kwsp.helloworld.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This class will behave differently in different locale as the first day of
 * week may be different.
 */
public class DateUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

	// date format
	public static final String ddMMyy = "ddMMyy";
	public static final String yyMMdd = "yyMMdd";
	public static final String HHmmss = "HHmmss";
	public static final String HH_mm_ss = "HH:mm:ss";
	public static final String yyyy_MM_dd = "yyyy-MM-dd";
	public static final String dd_MM_yyyy = "dd/MM/YYYY";
	public static final String yyyyMMddHHmmss = "yyyyMMddHHmmss";
	public static final String ddMMMyyyyhhmmaa = "dd MMM yyyy, hh:mm aa";
	public static final String dd_MMM_yyyyHHmmss = "dd-MMM-yyyy, HH:mm:ss";
	public static final String yyyy_MM_dd_HH_mm_ss_SSS = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String ddMMyyyyHHmmss = "ddMMyyyyHHmmss";

	private static final String WEEK_PREFIX = "w";
	private static final String SIMPLE_DATE_PATTERN = "yyMMdd";
	private static final String SIMPLE_DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";

	private static final String DEFAULT_DATE_TIME_PATTERN = yyyy_MM_dd_HH_mm_ss_SSS;

	private static final String ISO_DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
	private static final String DATE_TIME_PATTERN_TRANSNO = "yyyyMMddHHmmssSSSSSS";

	public static Date parseDefaultDate(String date) {
		DateFormat formatter = new SimpleDateFormat(SIMPLE_DATE_PATTERN);
		try {
			return formatter.parse(date);
		} catch (ParseException e) {
			LOGGER.error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * The week returned will not be compatible to ISO 8601
	 * 
	 * @param date
	 * @return
	 */
	public static String formatWeekInYear(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);

		int week = c.get(Calendar.WEEK_OF_YEAR);
		if (week == 1 && c.get(Calendar.YEAR) < c.getWeekYear()) {
			week = c.getMaximum(Calendar.WEEK_OF_YEAR);
		}

		return WEEK_PREFIX + week;
	}

	public static String formatShortMonth(Date date) {
		return new SimpleDateFormat(SIMPLE_DATE_PATTERN, Locale.US).format(date).substring(4, 6);
	}

	public static Integer formatYear(Date date) {
		return Integer.valueOf(new SimpleDateFormat(SIMPLE_DATE_PATTERN, Locale.US).format(date).substring(0, 4));
	}

	public static Integer previousYear(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.YEAR, -1);
		Date previousDate = cal.getTime();
		return formatYear(previousDate);
	}

	public static String formatSimpleDate(Date date) {
		return new SimpleDateFormat(SIMPLE_DATE_PATTERN).format(date);
	}

	public static String formatSimpleDateTime(Date date) {
		return new SimpleDateFormat(SIMPLE_DATE_TIME_PATTERN).format(date);
	}

	public static String formatDefaultDateTime(Date date) {
		return new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN).format(date);
	}

	public static String formatIsoDateTime(Date date) {
		return new SimpleDateFormat(ISO_DATE_TIME_PATTERN).format(date);
	}

	public static String formatDateTimeTransNo(Date date) {
		return new SimpleDateFormat(DATE_TIME_PATTERN_TRANSNO).format(date);
	}

	public static Date parseSimpleDateTime(String date) {
		try {
			return new SimpleDateFormat(SIMPLE_DATE_TIME_PATTERN).parse(date);
		} catch (ParseException e) {
			LOGGER.error(e.getMessage(), e);
			return null;
		}
	}

	public static String getCurrentDateTime() {
		return getCurrentDateTime(null);
	}

	public static String getCurrentDefaultDateTimeString() {
		return formatDefaultDateTime(getCurrentDefaultDateTime());
	}

	public static Date getCurrentDefaultDateTime() {
		return getCurrentDefaultDateTime(null);
	}

	public static Date getCurrentDefaultDateTime(String timeZoneVal) {
		TimeZone timeZone = null;
		Calendar calendar = new GregorianCalendar();

		if (timeZoneVal != null)
			timeZone = TimeZone.getTimeZone(timeZoneVal);

		if (timeZone != null) {
			calendar = Calendar.getInstance(timeZone);
		}

		return calendar.getTime();
	}

	public static String getCurrentDateTime(String timeZoneVal) {
		String dateTime = null;
		TimeZone timeZone = null;
		Calendar calendar = new GregorianCalendar();
		if (timeZoneVal != null)
			timeZone = TimeZone.getTimeZone(timeZoneVal);

		if (timeZone != null) {
//			calendar.setTimeZone(timeZone);
			calendar = Calendar.getInstance(timeZone);
		}
//		long timeLong = calendar.getTimeInMillis();
//		dateTime = formatIsoDateTime(calendar.getTime());
		dateTime = formatSimpleDateTime(calendar.getTime());
		return dateTime;
	}

	public static String convertDateToString(Date date, String dateFormat) {
		return convertDateToString(date, dateFormat, null);
	}

	public static String convertDateToString(Date date, String dateFormat, Locale locale) {
		DateFormat df = null;
		if (locale != null) {
			df = new SimpleDateFormat(dateFormat, locale);
		} else {
			df = new SimpleDateFormat(dateFormat);
		}

		String strDate = null;
		if (date != null) {
			strDate = df.format(date);
		}
		return strDate;
	}

	public static Date convertStringToDate(String dateStr, String dateFormat) {
		DateFormat df = new SimpleDateFormat(dateFormat);
		Date date = null;
		try {
			if (StringUtils.isNotBlank(dateStr))
				date = df.parse(dateStr);
		} catch (ParseException e) {
			LOGGER.error("failed to convertStringToDate(" + dateStr + ", " + dateFormat + ") ", e);
		}
		return date;
	}

	public static Date checkIsDate(String inputStr) {
		List<SimpleDateFormat> dateFormats = new ArrayList<>();
		dateFormats.add(new SimpleDateFormat("dd MMM yyyy, HH:mm:ss"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy HH:mm"));
		dateFormats.add(new SimpleDateFormat("M/dd/yyyy hh:mm:ss a"));
		dateFormats.add(new SimpleDateFormat("dd.M.yyyy hh:mm:ss a"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss aa"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aa"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss a"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss"));
		dateFormats.add(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yyyy"));
		dateFormats.add(new SimpleDateFormat("yyyy/MM/dd"));
		dateFormats.add(new SimpleDateFormat("d/MM/yyyy"));
		dateFormats.add(new SimpleDateFormat("dd/MM/yy"));
		dateFormats.add(new SimpleDateFormat("M/dd/yyyy"));
		dateFormats.add(new SimpleDateFormat("dd.M.yyyy"));
		dateFormats.add(new SimpleDateFormat("dd.MMM.yyyy"));
		dateFormats.add(new SimpleDateFormat("dd-MMM-yyyy"));
		dateFormats.add(new SimpleDateFormat("dd MMM yyyy"));
		dateFormats.add(new SimpleDateFormat("yyyy-MM-dd"));
		dateFormats.add(new SimpleDateFormat("dd-MM-yyyy"));
		dateFormats.add(new SimpleDateFormat("HH:mm"));
		dateFormats.add(new SimpleDateFormat("hh:mm aa"));
		dateFormats.add(new SimpleDateFormat("HH:mm:ss"));
		dateFormats.add(new SimpleDateFormat("hh:mm:ss aa"));

		Date date = null;
		if (StringUtils.isEmpty(inputStr)) {
			return null;
		}
		for (SimpleDateFormat format : dateFormats) {
			try {
				format.setLenient(false);
				date = format.parse(inputStr);
			} catch (ParseException e) {
				// Shhh.. try other formats
			}
			if (date != null) {
				break;
			}
		}
		return date;
	}
}
