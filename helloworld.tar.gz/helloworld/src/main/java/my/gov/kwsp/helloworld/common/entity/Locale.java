package my.gov.kwsp.helloworld.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the Locale database table.
 * 
 */
@Entity
@Table(name = "Locale", schema = "mip")
@NamedQuery(name = "Locale.findAll", query = "SELECT l FROM Locale l")
public class Locale implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5247188582109885029L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "localeId", updatable = false, nullable = false)
	private String localeId;

	@Column(name = "category")
	private String category;

	@Column(name = "description")
	private String description;

	@Column(name = "englishString")
	private String englishString;

	@Column(name = "bahasaString")
	private String bahasaString;

	@Column(name = "deleted")
	private Boolean deleted;

	@Column(name = "editable")
	private Boolean editable;

	@Column(name = "version")
	private Integer version;

	@Column(name = "createdBy")
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createdDatetime")
	private Date createdDatetime;

	@Column(name = "modifiedBy")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modifiedDatetime")
	private Date modifiedDatetime;

	public Locale() {
	}

	public String getLocaleId() {
		return localeId;
	}

	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEnglishString() {
		return englishString;
	}

	public void setEnglishString(String englishString) {
		this.englishString = englishString;
	}

	public String getBahasaString() {
		return bahasaString;
	}

	public void setBahasaString(String bahasaString) {
		this.bahasaString = bahasaString;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public Boolean getEditable() {
		return editable;
	}

	public void setEditable(Boolean editable) {
		this.editable = editable;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDatetime() {
		return createdDatetime;
	}

	public void setCreatedDatetime(Date createdDatetime) {
		this.createdDatetime = createdDatetime;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDatetime() {
		return modifiedDatetime;
	}

	public void setModifiedDatetime(Date modifiedDatetime) {
		this.modifiedDatetime = modifiedDatetime;
	}
}
