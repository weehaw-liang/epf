package my.gov.kwsp.helloworld.common.util;

public enum RegexUtil {

	NEW_PASSWORD_RULE("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,16}$"),

	;

	private String regex;

	private RegexUtil(String regex) {
		this.regex = regex;
	}

	public String getRegex() {
		return regex;
	}

	public void setRegex(String regex) {
		this.regex = regex;
	}

}
