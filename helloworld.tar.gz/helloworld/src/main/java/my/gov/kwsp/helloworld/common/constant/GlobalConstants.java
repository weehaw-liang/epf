package my.gov.kwsp.helloworld.common.constant;

public class GlobalConstants {

	// Locale
	public static final String LOCALE_EN = "en";
	public static final String LOCALE_MS = "ms";
	public static final String LOCALE_EN_US = "en_US";
	public static final String LOCALE_MS_MY = "ms_MY";
	public static final String LOCALE_DATA = "localeData";

	// API JSON header
	public static final String APP_LANG = "language"; // app language
	public static final String APP_PLATFORM = "platform"; // app platform
	public static final String APP_VERSION = "version"; // app version

	public static final String ACCESS_TOKEN = "accessToken"; // access token
	public static final String AUTHORIZATION = "authorization"; // authorization
	public static final String REQUEST_TIME = "requestTime"; // request time
	public static final String CLIENT_IP = "clientIp"; // client ip
	public static final String COOKIE_ID = "cookieId"; // cookie id

	public static final String AUTH_TOKEN = "sessionToken"; // session token
	public static final String API_VERSION = "avr"; // api version
	public static final String REQUEST_ID = "rid"; // request id
	public static final String DEVICE_OS = "dos"; // device operating system
	public static final String STATUS_CODE = "sta"; // status code
	public static final String MEMBER_INFO = "memberInfo"; // member info

	// API JSON param
	public static final String PAGE_NO = "pageNo";
	public static final String EPF_NO = "epfNo";
	public static final String OTHER_VALUE = "otherValue";
	public static final String BANK_LIST = "bankList";
	public static final String CONTRIBUTION_HISTORY_LIST = "paymentHistoryList";
	public static final String START_DATE = "startDate";
	public static final String END_DATE = "endDate";
	public static final String HTML = "html";
	public static final String FPX_RESPONSE = "fpxResponse";
	public static final String CONTRIBUTION_PAYMENT_STATUS = "contributionPaymentStatus";
	public static final String SELLER_ORDER_NO = "sellerOrderno";
	public static final String RECEIPT = "receipt";
	public static final String DOWNLOAD_URL = "downloadUrl";
	public static final String VOLUNTARY_SUBJECT = "VoluntarySubject";

	// fpx configuration
	public static final String FPX_MSGTYPE = "fpx_msgType";
	public static final String FPX_MSGTOKEN = "fpx_msgToken";
	public static final String FPX_FPXTXNID = "fpx_fpxTxnId";
	public static final String FPX_SELLEREXID = "fpx_sellerExId";
	public static final String FPX_SELLEREXORDERNO = "fpx_sellerExOrderNo";
	public static final String FPX_FPXTXNTIME = "fpx_fpxTxnTime";
	public static final String FPX_SELLERTXNTIME = "fpx_sellerTxnTime";
	public static final String FPX_SELLERORDERNO = "fpx_sellerOrderNo";
	public static final String FPX_SELLERID = "fpx_sellerId";
	public static final String FPX_SELLERBANKCODE = "fpx_sellerBankCode";
	public static final String FPX_TXNCURRENCY = "fpx_txnCurrency";
	public static final String FPX_TXNAMOUNT = "fpx_txnAmount";
	public static final String FPX_BUYEREMAIL = "fpx_buyerEmail";
	public static final String FPX_CHECKSUM = "fpx_checkSum";
	public static final String FPX_BUYERNAME = "fpx_buyerName";
	public static final String FPX_BUYERBANKID = "fpx_buyerBankId";
	public static final String FPX_BUYERBANKBRANCH = "fpx_buyerBankBranch";
	public static final String FPX_BUYERACCNO = "fpx_buyerAccNo";
	public static final String FPX_BUYERID = "fpx_buyerId";
	public static final String FPX_MAKERNAME = "fpx_makerName";
	public static final String FPX_BUYERIBAN = "fpx_buyerIban";
	public static final String FPX_PRODUCTDESC = "fpx_productDesc";
	public static final String FPX_DEBITAUTHCODE = "fpx_debitAuthCode";
	public static final String FPX_DEBITAUTHNO = "fpx_debitAuthNo";
	public static final String FPX_CREDITAUTHCODE = "fpx_creditAuthCode";
	public static final String FPX_CREDITAUTHNO = "fpx_creditAuthNo";
	public static final String FPX_BANKLIST = "fpx_bankList";
	public static final String FPX_VERSION = "fpx_version";

//	public static final SimpleDateFormat FPX_DATE_TIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");

	public static final String SELLER_BANK_CODE = "01";
	public static final String MSG_TYPE = "AE";
	public static final String VOLUNTARY_CONTRIBUTION_PRODUCT_DESC = "Bayaran Voluntary Contribution Bulanan";
	public static final String TXN_CURRENCY = "MYR";
	public static final String PIPE = "|";

	// transaction payment status (FPX)
	public static final String TXN_STATUS_SUCCESS = "SUCCESS";
	public static final String TXN_STATUS_IN_PROGRESS = "IN_PROGRESS";
	public static final String TXN_STATUS_PENDING = "PENDING";
	public static final String TXN_STATUS_NA = "NA";
	public static final String TXN_STATUS_SUBMITTED = "SUBMITTED";
	public static final String TXN_STATUS_CANCELLED = "CANCELLED";
	public static final String TXN_STATUS_FAIL = "FAIL";

	public static final String TXN_TYPE_SELF_CONTRIBUTION = "MVC";
	public static final String TXN_TYPE_CONTRIBUTE_TO_OTHER = "MTC";

	public static final String TXN_TYPE_SELF_CONTRIBUTION_PERF = "PVC";
	public static final String TXN_TYPE_CONTRIBUTE_TO_OTHER_PERF = "PTC";

	public static final String TXN_TYPE_SELLER_ORDER_NO_SELF_CONTRIBUTION = "V1";
	public static final String TXN_TYPE_SELLER_ORDER_NO_CONTRIBUTE_TO_OTHER = "V2";

	// TODO remove after Testing. for testing purpose
	public static final String TXN_TYPE_SELLER_ORDER_NO_SELF_CONTRIBUTION_LOCAL = "L1";
	public static final String TXN_TYPE_SELLER_ORDER_NO_CONTRIBUTE_TO_OTHER_LOCAL = "L2";

	public static final String TXN_TYPE_SELLER_ORDER_NO_SELF_CONTRIBUTION_DEV = "D1";
	public static final String TXN_TYPE_SELLER_ORDER_NO_CONTRIBUTE_TO_OTHER_DEV = "D2";

	public static final String TXN_TYPE_SELLER_ORDER_NO_SELF_CONTRIBUTION_PERF = "P1";
	public static final String TXN_TYPE_SELLER_ORDER_NO_CONTRIBUTE_TO_OTHER_PERF = "P2";

	// map key
	public static final String CODE = "code";
	public static final String DESC = "desc";

	// JSON param - fpx auth enquiry
	public static final String TXN_DEBITAUTHCODE = "trnDebitAuthCode";
	public static final String TXN_AMOUNT = "trnAmount";
	public static final String TXN_BANK = "trnBank";
	public static final String FPXSELLERORDERNO = "fpxSellerOrderNo";
	public static final String FPXSTATUS = "fpxStatus";
	public static final String TXN_DATETIME = "trnDatetime";
	public static final String TXN_STATUS = "trnStatus";
	public static final String TXN_ID = "trnID";

	public static final String HTTP_STATUS = "httpStatus";
	public static final String BASE_REPSONSE = "baseResponse";

	public static final String BOOLEAN_YES_STRING = "Y";
	public static final String BOOLEAN_NO_STRING = "N";
	public static final String RESULT_STATUS_SUCCESS = "S";
	public static final String RESULT_STATUS_FAIL = "F";
	public static final String RESULT_STATUS_ACCEPTED = "A";
	public static final String ESB_SUCCESS_RESPONSE_CODE = "0";
	public static final String RESULT_MESSAGE_FAIL = "fail";

	public static final String LOGGER_EXCEPTION = "Exception: {}";

}
