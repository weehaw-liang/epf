package my.gov.kwsp.helloworld.common.enumeration;

public enum LocaleCategory implements GenericEnum {

	FPX("fpx", "FPX response code"),
	
	EPF_FPX("epf_fpx", "Fpx Status show in EPF"),
	
	EPF_ESB("epf_esb", "ESB Status show in EPF"),

	;

	private final String code;

	private final String description;

	private LocaleCategory(String code, String description) {
		this.code = code;
		this.description = description;
	}

	@Override
	public String getCode() {
		return this.code;
	}

	@Override
	public String getDescription() {
		return this.description;
	}

}
