package my.gov.kwsp.helloworld.common.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import my.gov.kwsp.helloworld.common.entity.SequenceNumber;
import my.gov.kwsp.helloworld.common.repository.SequenceNumberRepo;
import my.gov.kwsp.helloworld.common.service.SequenceNumberService;

@Service
public class SequenceNumberServiceImpl implements SequenceNumberService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SequenceNumberServiceImpl.class);

	@Autowired
	private SequenceNumberRepo sequenceNumberRepo;

	@Transactional(rollbackFor = Exception.class)
	@Override
	public Integer getNext(String seqCode) {
		LOGGER.info("getNext called.");

		SequenceNumber no = sequenceNumberRepo.findBySeqCode(seqCode);
		if (no == null) {
			no = new SequenceNumber();
			no.setNextSeq(0);
			no.setSeqCode(seqCode);
			no.setMaxLimit(99999);
			no = sequenceNumberRepo.saveAndFlush(no);
		}

		return createSequenceNoBean(no);
	}

	private Integer createSequenceNoBean(SequenceNumber no) {

		Integer nextSeq = no.getNextSeq() + 1;
		if (no.getMaxLimit() != null) {
			if (nextSeq < no.getMaxLimit()) {
				no.setNextSeq(nextSeq);
			} else {
				no.setNextSeq(0);
			}
		}

		no = sequenceNumberRepo.saveAndFlush(no);

		return no.getNextSeq();
	}
}