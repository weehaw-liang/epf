package my.gov.kwsp.helloworld.common.util;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import my.gov.kwsp.helloworld.common.bean.BaseResponse;
import my.gov.kwsp.helloworld.common.constant.GlobalConstants;
import my.gov.kwsp.helloworld.common.exception.ExceptionCode;

@RestControllerAdvice
public class ValidationHandler extends ResponseEntityExceptionHandler {

	BaseResponse baseResponse = new BaseResponse();

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		HttpStatus rStatus = HttpStatus.OK;
		for (ObjectError error : ex.getBindingResult().getAllErrors()) {
			if (error instanceof FieldError) {
				FieldError fieldError = (FieldError) error;
				if (fieldError.getRejectedValue() != null && !fieldError.getRejectedValue().toString().isEmpty()) {
					try {
						ExceptionCode exceptionCode = ExceptionCode.valueOf(fieldError.getDefaultMessage());
						baseResponse = new BaseResponse(exceptionCode);
						baseResponse.setResultStatus(GlobalConstants.RESULT_STATUS_FAIL);

					} catch (Exception e) {
						baseResponse = new BaseResponse(ExceptionCode.MISSING_PARAM_REQUEST);
						baseResponse.setResultStatus(GlobalConstants.RESULT_STATUS_FAIL);
						rStatus = HttpStatus.BAD_REQUEST;
					}
				} else {
					baseResponse = new BaseResponse(ExceptionCode.MISSING_PARAM_REQUEST);
					baseResponse.setResultStatus(GlobalConstants.RESULT_STATUS_FAIL);
					rStatus = HttpStatus.BAD_REQUEST;
				}

				break;
			}
		}
		return new ResponseEntity<Object>(baseResponse, rStatus);
	}
}