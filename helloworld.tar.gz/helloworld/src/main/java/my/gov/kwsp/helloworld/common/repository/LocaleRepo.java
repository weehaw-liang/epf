package my.gov.kwsp.helloworld.common.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import my.gov.kwsp.helloworld.common.entity.Locale;

@Repository
public interface LocaleRepo extends JpaRepository<Locale, Long> {

	@Query("select l from Locale l " + " where l.localeId = :localeId " + " and l.deleted <> 1 ")
	Locale findByLocaleId(@Param("localeId") String localeId);

	@Query("select l.englishString from Locale l " + " where l.localeId = :localeId " + " and l.deleted <> 1 ")
	String getEnglishStringByLocaleId(@Param("localeId") String localeId);

	@Query("select l.bahasaString from Locale l " + " where l.localeId = :localeId " + " and l.deleted <> 1 ")
	String getBahasaStringByLocaleId(@Param("localeId") String localeId);

	@Query("select l from Locale l " + " where l.category = :category " + " and l.deleted <> 1 ")
	List<Locale> findAllbyCategoryAndDeletedFalse(@Param("category") String category);

	@Query("select l from Locale l " + " where l.deleted <> 1 ")
	List<Locale> findAllNotDeleted();
}
