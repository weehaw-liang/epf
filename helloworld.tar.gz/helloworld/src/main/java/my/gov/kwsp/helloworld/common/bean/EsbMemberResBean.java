package my.gov.kwsp.helloworld.common.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import my.gov.kwsp.helloworld.common.bean.esb.CommonMemberResponse;
import my.gov.kwsp.helloworld.common.bean.esb.CommonMessageHeader;


@JsonIgnoreProperties(ignoreUnknown = true)
public class EsbMemberResBean {

	private CommonMessageHeader header;
	private CommonMemberResponse response;

	public EsbMemberResBean() {
	}

	public CommonMessageHeader getHeader() {
		return header;
	}

	public void setHeader(CommonMessageHeader header) {
		this.header = header;
	}

	public CommonMemberResponse getResponse() {
		return response;
	}

	public void setResponse(CommonMemberResponse response) {
		this.response = response;
	}

}