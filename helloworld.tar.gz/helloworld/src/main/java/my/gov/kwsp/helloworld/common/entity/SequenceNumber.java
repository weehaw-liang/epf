package my.gov.kwsp.helloworld.common.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the SequenceNumber database table.
 * 
 */
@Entity
@Table(name = "SequenceNumber", schema = "mip")
@NamedQuery(name = "SequenceNumber.findAll", query = "SELECT s FROM SequenceNumber s")
public class SequenceNumber implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "seqCode", unique = true, updatable = false, nullable = false)
	private String seqCode;

	@Column(name = "nextSeq")
	private Integer nextSeq;

	@Column(name = "maxLimit")
	private Integer maxLimit;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modifiedDatetime")
	private Date modifiedDatetime;

	public SequenceNumber() {
	}

	public String getSeqCode() {
		return seqCode;
	}

	public void setSeqCode(String seqCode) {
		this.seqCode = seqCode;
	}

	public Integer getNextSeq() {
		return nextSeq;
	}

	public void setNextSeq(Integer nextSeq) {
		this.nextSeq = nextSeq;
	}

	public Integer getMaxLimit() {
		return maxLimit;
	}

	public void setMaxLimit(Integer maxLimit) {
		this.maxLimit = maxLimit;
	}

	public Date getModifiedDatetime() {
		return modifiedDatetime;
	}

	public void setModifiedDatetime(Date modifiedDatetime) {
		this.modifiedDatetime = modifiedDatetime;
	}
}