package my.gov.kwsp.helloworld.common.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import my.gov.kwsp.helloworld.bean.ValidateAccessTokenReqBean;
import my.gov.kwsp.helloworld.bean.ValidateAccessTokenResBean;
import my.gov.kwsp.helloworld.common.constant.GlobalConstants;
import my.gov.kwsp.helloworld.common.service.ValidateTokenService;
import my.gov.kwsp.helloworld.common.util.HttpsClientUtil;

@Service
public class ValidateTokenServiceImpl implements ValidateTokenService {

	private static final Logger LOGGER = LoggerFactory.getLogger(ValidateTokenServiceImpl.class);

	@Value("${configMap.authorizations.interservice.url}")
	private String authInterserviceUrl;

	@Value("${configMap.authorizations.interservice.validateAccessToken.url}")

	private String authValidateAccessTokenUrl;

	@Override
	public ValidateAccessTokenResBean postValidateAccessToken(String serviceURL, String token) {
		LOGGER.info("postValidateAccessToken called");

		ValidateAccessTokenReqBean requestEntity = new ValidateAccessTokenReqBean();
		requestEntity.setServiceURL(serviceURL);

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			String requestEntityStr = objectMapper.writeValueAsString(requestEntity);
			String destinationUrl = authInterserviceUrl + authValidateAccessTokenUrl;

			LOGGER.info("postValidateAccessToken destinationUrl: {}", destinationUrl);

			return postValidateAccessTokenLive(destinationUrl, requestEntityStr, token);
		} catch (JsonProcessingException e) {
			LOGGER.error("Failed to convert Object to JsonString : {}", requestEntity);
			LOGGER.error(GlobalConstants.LOGGER_EXCEPTION, e);
		}

		return null;
	}

	private ValidateAccessTokenResBean postValidateAccessTokenLive(String destinationUrl, String requestEntityStr,
			String token) {

		LOGGER.info("postValidateAccessTokenLive called");

		String[][] httpHeaders = { { HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE }, { "language", "en" },
				{ "platform", "ANDROID" }, { "requestTime", "2022-08-01 08:00:00.000" }, { "accessToken", token } };

		HttpsClientUtil hch = new HttpsClientUtil(false);

		try {
			hch.sendPost(destinationUrl, requestEntityStr, httpHeaders);
		} catch (Exception e) {
			LOGGER.error("hch.sendPost hit error on URL {} ", destinationUrl);
			LOGGER.error(GlobalConstants.LOGGER_EXCEPTION, e);
		}

		LOGGER.info("postValidateAccessTokenLive hch.getResponseCode(): {}", hch.getResponseCode());
		LOGGER.info("postValidateAccessTokenLive hch.getResponseContent(): {}", hch.getResponseContent());

		if (StringUtils.isNotBlank(hch.getResponseContent())) {
			if (!"ERROR".equalsIgnoreCase(hch.getResponseContent())
					&& !"PROSESSING ERROR".equalsIgnoreCase(hch.getResponseContent())) {

				try {
					ObjectMapper objectMapper = new ObjectMapper();
					return objectMapper.readValue(hch.getResponseContent(), ValidateAccessTokenResBean.class);
				} catch (Exception e2) {
					LOGGER.error("Failed to convert responseEntity - {} ", hch.getResponseContent());
					LOGGER.error(GlobalConstants.LOGGER_EXCEPTION, e2);
				}
			}
		} else {
			LOGGER.error("mapper responseEntity.getBody() is empty");
		}

		return null;
	}

}
