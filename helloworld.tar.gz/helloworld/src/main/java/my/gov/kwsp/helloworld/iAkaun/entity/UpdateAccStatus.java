package my.gov.kwsp.helloworld.iAkaun.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "UpdateAccStatus", schema = "dbo")
public class UpdateAccStatus implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -842615631785275399L;

	@Column(name = "userId")
	private String userId;

	@Id
	@Column(name = "accId", updatable = false, nullable = false)
	private Long accId;

	@Column(name = "epfAccNo")
	private String epfAccNo;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getAccId() {
		return accId;
	}

	public void setAccId(Long accId) {
		this.accId = accId;
	}

	public String getEpfAccNo() {
		return epfAccNo;
	}

	public void setEpfAccNo(String epfAccNo) {
		this.epfAccNo = epfAccNo;
	}
}