package my.gov.kwsp.helloworld.bean;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
//@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidateAccessTokenResBean {

	private String resultCode;

	private String resultStatus;

	private String resultMessage;

	private Map<String, Object> data;

	public String getResultCode() {
		return resultCode;
	}

	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}

	public String getResultStatus() {
		return resultStatus;
	}

	public void setResultStatus(String resultStatus) {
		this.resultStatus = resultStatus;
	}

	public Map<String, Object> getData() {
		return data;
	}

	public String getResultMessage() {
		return resultMessage;
	}

	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}

	public void setData(Map<String, Object> data) {
		this.data = data;
	}

	public Object addData(String key, Object value) {
		if (this.data == null) {
			this.data = new HashMap<>();
		}

		return data.put(key, value);
	}

}
