package my.gov.kwsp.helloworld.common.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

public class HttpsClientUtil {
	private HttpStatus httpStatus;
	private int responseCode;
	private String responseContent;
	private boolean enableSSL = true;
	private int timeout;
	private static final String TLS_VERSION = "TLSv1.2";

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpsClientUtil.class);

	public HttpsClientUtil(boolean enableSSL) {
		this(enableSSL, 60000);
	}

	public HttpsClientUtil(boolean enableSSL, int timeout) {
		this.enableSSL = enableSSL;
		this.timeout = timeout;
		this.httpStatus = HttpStatus.FORBIDDEN;
	}

	public void sendPost(String url, String parameter, String[][] properties) throws Exception {
		LOGGER.info("Sending request to {}", url);
		LOGGER.info("Parameters : {}", parameter);

		URL obj = new URL(url);

		if (!this.enableSSL) {

			LOGGER.info("byPassSSL Post {}", url);

			TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return new X509Certificate[0];
				}

				public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
				}
			} };
			SSLContext sslContext = SSLContext.getInstance(TLS_VERSION);
			sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sslContext.getSocketFactory());
			System.setProperty("https.protocols", TLS_VERSION);
			HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {

				@Override
				public boolean verify(String arg0, SSLSession arg1) {
					return true;
				}
			});
		} else {
			LOGGER.info("SSL Post {}", url);
		}

		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		// HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();
		con.setRequestMethod(HttpMethod.POST.name());
		for (String[] pro : properties) {
			con.setRequestProperty(pro[0], pro[1]);
		}
		con.setConnectTimeout(this.timeout);
		con.setDoOutput(true);
		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		if (StringUtils.isNotBlank(parameter)) {
			wr.writeBytes(parameter);
		}
		wr.flush();
		wr.close();

		this.httpStatus = HttpStatus.valueOf(con.getResponseCode());

		if (this.httpStatus.is2xxSuccessful()) {

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			this.responseContent = response.toString();

		} else {

			BufferedReader in = new BufferedReader(new InputStreamReader(con.getErrorStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			this.responseContent = response.toString();
		}

		LOGGER.info("Receive response from {}", url);
		LOGGER.info("Response Code : " + this.httpStatus.value());
		LOGGER.info("Response Content : " + this.responseContent);
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public int getResponseCode() {
		this.responseCode = this.httpStatus.value();
		return responseCode;
	}

	public String getResponseContent() {
		return responseContent;
	}

	public void setEnableSSL(boolean enableSSL) {
		this.enableSSL = enableSSL;
	}

	public boolean isEnableSSL() {
		return enableSSL;
	}

}
