package my.gov.kwsp.helloworld.controllers;

import java.util.Date;
import java.util.concurrent.ConcurrentMap;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hazelcast.core.HazelcastInstance;

import io.swagger.annotations.ApiOperation;
import my.gov.kwsp.helloworld.bean.MemberInfoReqBean;
import my.gov.kwsp.helloworld.common.bean.BaseResponse;
import my.gov.kwsp.helloworld.common.exception.ExceptionCode;
import my.gov.kwsp.helloworld.common.repository.LocaleRepo;
import my.gov.kwsp.helloworld.common.service.LocaleService;
import my.gov.kwsp.helloworld.common.util.BaseUtil;
import my.gov.kwsp.helloworld.iAkaun.repository.MemberAccStatusRepo;
import my.gov.kwsp.helloworld.service.HelloWorldService;

@RestController
@RequestMapping(value = { "api/", "/api" })
public class HelloWorldController extends BaseUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(HelloWorldController.class);

	@Autowired
	private HelloWorldService helloWorldService;

//	@Autowired
//	private HazelcastMemberProfileService hazelService;

//	private HazelcastInstance hazelcastInstance;

	@Autowired
	HazelcastInstance hazelcastInstance;

	private ConcurrentMap<String, String> retrieveMap() {
		return hazelcastInstance.getMap("membersProfile");
	}

	public HelloWorldController(LocaleService localeService) {
		super(localeService);
	}

//	@Autowired
//	private ValidationService validationService;

	@Autowired
	private MemberAccStatusRepo memberAccStatusRepo;

	@Autowired
	private LocaleRepo localeRepo;

	@ApiOperation(value = "Hello")
	@GetMapping(value = "/hello", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHello() {
		return "Hello World, Spring Boot!";
	}

	@ApiOperation(value = "hazelcastPut")
	@GetMapping(value = "/hazelcastPut", produces = MediaType.APPLICATION_JSON_VALUE)
	public String putHazelcast(HttpServletRequest request, @RequestParam String name, @RequestParam String key) {
		LOGGER.info("hazelcastPut key : {}", key);
		LOGGER.info("hazelcastPut value : {}", name);
//		MemberProfile profile = new MemberProfile();
//		profile.setName1(name);
//		profile.setAccessToken(key);

		retrieveMap().put(key, name);

//		MemberProfile profileAfter = hazelService.put(key, profile);

		return retrieveMap().get(key);
	}

	@ApiOperation(value = "hazelcastGet")
	@GetMapping(value = "/hazelcastGet", produces = MediaType.APPLICATION_JSON_VALUE)
	public String getHazelcast(HttpServletRequest request, @RequestParam String key) {
		LOGGER.info("hazelcastGet : {}", key);
		Date startDate = new Date();
		String r = retrieveMap().get(key);
		LOGGER.info("Time taken : {}", (new Date().getTime() - startDate.getTime()));
//		MemberProfile profile = hazelService.get(key);
		return r;
	}

	@ApiOperation(value = "get_two_db_conn")
	@GetMapping(value = "/getTwoDbConn", produces = MediaType.APPLICATION_JSON_VALUE)
	public String get_two_db_conn() {

		String epfNo = memberAccStatusRepo.findByMemberUserId("automationtest02");
		String localeId = localeRepo.getBahasaStringByLocaleId("1H");

		return "[DB: iAkaun] epfNo: " + epfNo + " [DB: MIP] localeId: " + localeId;
	}

	@ApiOperation(value = "helloNoFilter")
	@GetMapping(value = "/v2/helloNoFilter", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> getHelloNoFilter(HttpServletRequest request) {

		BaseResponse response = new BaseResponse();

		response = new BaseResponse(ExceptionCode.NO_ERROR);
		response.setResultStatus("S");
		response.setResultMessage("Success");
		HttpStatus status = HttpStatus.OK;

		return ResponseEntity.status(status).body(response);
	}

	@ApiOperation(value = "noFilterWithSQL")
	@GetMapping(value = "/v1/noFilterWithSQL", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> getNoFilterSQL(HttpServletRequest request) {

		BaseResponse response = new BaseResponse();

		response = helloWorldService.getFPXBankList();
		HttpStatus status = HttpStatus.OK;

		return ResponseEntity.status(status).body(response);
	}

	@ApiOperation(value = "noFilterWithESB")
	@PostMapping(value = "/v1/noFilterWithESB", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<BaseResponse> getNoFilterESB(HttpServletRequest request,
			@Valid @RequestBody MemberInfoReqBean requestBody, Errors errors) {

		BaseResponse response = new BaseResponse();

		response = helloWorldService.getMemberDetails(requestBody);
		HttpStatus status = HttpStatus.OK;

		return ResponseEntity.status(status).body(response);
	}

}