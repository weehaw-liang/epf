package my.gov.kwsp.helloworld.common.exception;

import org.springframework.http.HttpStatus;

import my.gov.kwsp.helloworld.common.constant.GlobalConstants;

public enum ExceptionCode {

	NO_ERROR("0000", "Successful", GlobalConstants.RESULT_STATUS_SUCCESS, HttpStatus.OK),

	/***************************************************************************
	 * System / Apps error
	 ***************************************************************************/
	INTERNAL_ERROR(prefix() + "1000", "INTERNAL_ERROR", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	UNKNOWN_ERROR(prefix() + "1001", "UNKNOWN_ERROR", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	SYSTEM_UNAVAILABLE(prefix() + "1002", "SYSTEM_UNAVAILABLE", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_TOKEN(prefix() + "1003", "INVALID_TOKEN", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_REQUEST(prefix() + "1004", "INVALID_REQUEST", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_SESSION(prefix() + "1005", "INVALID_SESSION", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_APP_LANG(prefix() + "1006", "INVALID_APP_LANG", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	SESSION_TIMEOUT(prefix() + "1007", "SESSION_TIMEOUT", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	RECORD_NOT_FOUND(prefix() + "1008", "RECORD_NOT_FOUND", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	CONNECTION_TIMEOUT(prefix() + "1009", "CONNECTION_TIMEOUT", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_AMOUNT(prefix() + "1010", "INVALID_AMOUNT", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	USER_NOT_AUTHORIZED(prefix() + "1011", "USER_NOT_AUTHORIZED", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	USER_AGE_ABOVE_75(prefix() + "1012", "USER_AGE_ABOVE_75", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	USER_AGE_BELOW_14(prefix() + "1013", "USER_AGE_BELOW_14", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	NO_RECORD_UPDATE(prefix() + "1014", "NO_RECORD_UPDATE", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_ID_TYPE(prefix() + "1015", "INVALID_ID_TYPE", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),

	/***************************************************************************
	 * Param missing
	 ***************************************************************************/
	MISSING_TOKEN(prefix() + "2000", "MISSING_TOKEN", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_DEVICE_ID(prefix() + "2001", "MISSING_DEVICE_ID", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_DEVICE_OS(prefix() + "2002", "MISSING_DEVICE_OS", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_REQUEST_ID(prefix() + "2003", "MISSING_REQUEST_ID", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_LANG(prefix() + "2004", "MISSING_LANG", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_APP_VERSION(prefix() + "2005", "MISSING_APP_VERSION", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_EPF_NO(prefix() + "2006", "MISSING_EPF_NO", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_TXN_AMOUNT(prefix() + "2007", "MISSING_TXN_AMOUNT", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MISSING_BUYER_BANK_ID(prefix() + "2008", "MISSING_BUYER_BANK_ID", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.OK),
	MISSING_SELLER_ORDER_NO(prefix() + "2009", "MISSING_SELLER_ORDER_NO", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.OK),
	MISSING_APP_PLATFORM(prefix() + "2010", "MISSING_APP_PLATFORM", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),

	MISSING_PARAM_REQUEST("400", "MISSING_PARAM_REQUEST", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.BAD_REQUEST),
	MISSING_PARAM_REQUEST_CONTENT_TYPE("400", "MISSING_PARAM_REQUEST_CONTENT_TYPE", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.BAD_REQUEST),
	MISSING_PARAM_REQUEST_APP_LANG("400", "MISSING_PARAM_REQUEST_APP_LANG", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.BAD_REQUEST),
	MISSING_PARAM_REQUEST_APP_PLATFORM("400", "MISSING_PARAM_REQUEST_APP_PLATFORM", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.BAD_REQUEST),
	MISSING_PARAM_REQUEST_REQ_TIME("400", "MISSING_PARAM_REQUEST_REQUEST_TIME", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.BAD_REQUEST),
	MISSING_PARAM_REQUEST_ACCESS_TOKEN("400", "MISSING_PARAM_REQUEST_ACCESS_TOKEN", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.BAD_REQUEST),

	INVALID_AGE("WDW007", "Age should be between 18 to 55.", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),

	/***************************************************************************
	 * Result error
	 ***************************************************************************/
	VOLUNTARY_MIN_AMOUNT(prefix() + "3000", "VOLUNTARY_MIN_AMOUNT", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	EXCEED_AVAILABLE_VOLUNTARY_BALANCE(prefix() + "3001", "EXCEED_AVAILABLE_VOLUNTARY_BALANCE",
			GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	MEMBER_INACTIVE(prefix() + "3002", "MEMBER_INACTIVE", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	EXCEED_TRX_LIMIT(prefix() + "3003", "EXCEED_TRX_LIMIT", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	NOT_ALLOW_PASSPOST_HOLDER(prefix() + "3004", "NOT_ALLOW_PASSPOST_HOLDER", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.OK),

	CONTRIBUTION_YEARLY_LIMIT(prefix() + "3013", "CONTRIBUTION_HISTORY_TITLE", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.OK),
	CONTRIBUTION_HISTORY_ACCUMULATED_AMOUNT(prefix() + "3014", "CONTRIBUTION_HISTORY_ACCUMULATED_AMOUNT",
			GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	CONTRIBUTION_HISTORY_MSG_LABEL1(prefix() + "3015", "CONTRIBUTION_HISTORY_MSG_LABEL1",
			GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	CONTRIBUTION_HISTORY_MSG_LABEL2(prefix() + "3016", "CONTRIBUTION_HISTORY_MSG_LABEL2",
			GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	CONTRIBUTION_HISTORY_MSG_LABEL_URL(prefix() + "3017", "CONTRIBUTION_HISTORY_MSG_LABEL_URL",
			GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	CONTRIBUTION_HISTORY_LIST_TITLE(prefix() + "3018", "CONTRIBUTION_HISTORY_LIST_TITLE",
			GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),

	ESB_ID_NOT_FOUND(prefix() + "3100", "ESB_ID_NOT_FOUND", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_ACC_INACTIVE(prefix() + "3101", "ESB_ACC_INACTIVE", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_INVALID_ID(prefix() + "3102", "ESB_INVALID_ID", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_INVALID_NAME(prefix() + "3103", "ESB_INVALID_NAME", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_MISSING_NAME(prefix() + "3104", "ESB_MISSING_NAME", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_MISSING_NO(prefix() + "3105", "ESB_MISSING_NO", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_ACC_NOT_SAME(prefix() + "3106", "ESB_ACC_NOT_SAME", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	ESB_DEATH_TAGGING(prefix() + "3107", "ESB_DEATH_TAGGING", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),

	/***************************************************************************
	 * Authorization result error
	 ***************************************************************************/
	POST_LOGIN_FAILED("A4003", "POST_LOGIN_FAILED", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_PASSWORD_RULES("AUP4001", "INVALID_PASSWORD_RULE", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	PASSWORD_SAME_AS_PREVIOUS("AUP4002", "PASSWORD_SAME_AS_PREVIOUS", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.OK),
	INVALID_OLD_PASSWORD("AUP4003", "INVALID_OLD_PASSWORD", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.OK),
	INVALID_ACCESS_TOKEN("A4000", "INVALID_ACCESS_TOKEN", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.UNAUTHORIZED),
	ACCESS_TOKEN_EXPIRED("A4001", "ACCESS_TOKEN_EXPIRED", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.UNAUTHORIZED),

	INVALID_REFRESH_TOKEN("A4002", "INVALID_REFRESH_TOKEN", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.UNAUTHORIZED),
	REFRESH_TOKEN_EXPIRED("A4003", "REFRESH_TOKEN_EXPIRED", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.UNAUTHORIZED),
	USER_UNAUTHORIZED("A4007", "USER_UNAUTHORIZED", GlobalConstants.RESULT_STATUS_FAIL, HttpStatus.FORBIDDEN),

	INVALID_SECURITY_IMAGE_URL("AUS1001", "INVALID_SECURITY_IMAGE_URL", GlobalConstants.RESULT_STATUS_FAIL,
			HttpStatus.OK),;

	private final String code;
	private final String description;
	private final String status;
	private final HttpStatus httpStatus;

	ExceptionCode(String code, String desc, HttpStatus httpStatus) {
		this(code, desc, "", httpStatus);
	}

	ExceptionCode(String code, String desc, String status, HttpStatus httpStatus) {
		this.code = code;
		this.description = desc;
		this.status = status;
		this.httpStatus = httpStatus;
	}

	public String code() {
		return code;
	}

	public String description() {
		return description;
	}

	public String status() {
		return status;
	}

	public HttpStatus httpStatus() {
		return httpStatus;
	}

	public static String prefix() {
		return "M";
	}

	public static ExceptionCode getEnum(String code) {
		for (ExceptionCode exceptionCode : values()) {
			if (exceptionCode.code.equalsIgnoreCase(code)) {
				return exceptionCode;
			}
		}

		return null;
//		throw new IllegalArgumentException("Unable to parse exception code.");
	}
}
