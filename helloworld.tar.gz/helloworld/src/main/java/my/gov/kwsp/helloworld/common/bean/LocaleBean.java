package my.gov.kwsp.helloworld.common.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LocaleBean {

	private String localeId;
	private String englishString;
	private String bahasaString;

	public LocaleBean() {
	}

	public LocaleBean(String localeId, String englishString, String bahasaString) {
		this.localeId = localeId;
		this.englishString = englishString;
		this.bahasaString = bahasaString;
	}

	public String getLocaleId() {
		return localeId;
	}

	public void setLocaleId(String localeId) {
		this.localeId = localeId;
	}

	public String getEnglishString() {
		return englishString;
	}

	public void setEnglishString(String englishString) {
		this.englishString = englishString;
	}

	public String getBahasaString() {
		return bahasaString;
	}

	public void setBahasaString(String bahasaString) {
		this.bahasaString = bahasaString;
	}
}
