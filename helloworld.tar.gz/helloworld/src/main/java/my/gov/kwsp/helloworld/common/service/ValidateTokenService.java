package my.gov.kwsp.helloworld.common.service;

import my.gov.kwsp.helloworld.bean.ValidateAccessTokenResBean;

public interface ValidateTokenService {

	public ValidateAccessTokenResBean postValidateAccessToken(String serviceURL, String token);
}
