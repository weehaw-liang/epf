package my.gov.kwsp.helloworld.common.bean.esb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonMessageHeader {

	private String versionNo;
	private String transCode;
	private String applId;
	private String applTransId;
	private String transDatetime;

	public CommonMessageHeader() {
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getTransCode() {
		return transCode;
	}

	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}

	public String getApplId() {
		return applId;
	}

	public void setApplId(String applId) {
		this.applId = applId;
	}

	public String getApplTransId() {
		return applTransId;
	}

	public void setApplTransId(String applTransId) {
		this.applTransId = applTransId;
	}

	public String getTransDatetime() {
		return transDatetime;
	}

	public void setTransDatetime(String transDatetime) {
		this.transDatetime = transDatetime;
	}
}