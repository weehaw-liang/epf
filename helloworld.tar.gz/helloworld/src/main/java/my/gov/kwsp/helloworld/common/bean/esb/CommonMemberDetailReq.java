package my.gov.kwsp.helloworld.common.bean.esb;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonMemberDetailReq {

	private String cifNum;
	private String custName;
	private String birthDate;
	private String passportNum;
	private String gender;
	private String citizenCountry;
	private String race;
	private String religion;
	private String epfRegDate;
	private String residentStatus;
	private String homePhone;
	private String officePhone;
	private String mobilePhone;
	private String faxNum;
	private String emailAdd;
	private String effectiveDate;
	private String islamicFlag;
	private String primaryIdNum;
	private String tacMobilePhone;
	private String tacMobilePhoneStatus;
	private String electAddGrpSeq;
	private String cifCategory;
	private String accNum;
	private String indicator4;

	public CommonMemberDetailReq() {

	}

	public String getCifNum() {
		return cifNum;
	}

	public void setCifNum(String cifNum) {
		this.cifNum = cifNum;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getPassportNum() {
		return passportNum;
	}

	public void setPassportNum(String passportNum) {
		this.passportNum = passportNum;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCitizenCountry() {
		return citizenCountry;
	}

	public void setCitizenCountry(String citizenCountry) {
		this.citizenCountry = citizenCountry;
	}

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getReligion() {
		return religion;
	}

	public void setReligion(String religion) {
		this.religion = religion;
	}

	public String getEpfRegDate() {
		return epfRegDate;
	}

	public void setEpfRegDate(String epfRegDate) {
		this.epfRegDate = epfRegDate;
	}

	public String getResidentStatus() {
		return residentStatus;
	}

	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}

	public String getHomePhone() {
		return homePhone;
	}

	public void setHomePhone(String homePhone) {
		this.homePhone = homePhone;
	}

	public String getOfficePhone() {
		return officePhone;
	}

	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}

	public String getMobilePhone() {
		return mobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}

	public String getFaxNum() {
		return faxNum;
	}

	public void setFaxNum(String faxNum) {
		this.faxNum = faxNum;
	}

	public String getEmailAdd() {
		return emailAdd;
	}

	public void setEmailAdd(String emailAdd) {
		this.emailAdd = emailAdd;
	}

	public String getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(String effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public String getIslamicFlag() {
		return islamicFlag;
	}

	public void setIslamicFlag(String islamicFlag) {
		this.islamicFlag = islamicFlag;
	}

	public String getPrimaryIdNum() {
		return primaryIdNum;
	}

	public void setPrimaryIdNum(String primaryIdNum) {
		this.primaryIdNum = primaryIdNum;
	}

	public String getTacMobilePhone() {
		return tacMobilePhone;
	}

	public void setTacMobilePhone(String tacMobilePhone) {
		this.tacMobilePhone = tacMobilePhone;
	}

	public String getTacMobilePhoneStatus() {
		return tacMobilePhoneStatus;
	}

	public void setTacMobilePhoneStatus(String tacMobilePhoneStatus) {
		this.tacMobilePhoneStatus = tacMobilePhoneStatus;
	}

	public String getElectAddGrpSeq() {
		return electAddGrpSeq;
	}

	public void setElectAddGrpSeq(String electAddGrpSeq) {
		this.electAddGrpSeq = electAddGrpSeq;
	}

	public String getCifCategory() {
		return cifCategory;
	}

	public void setCifCategory(String cifCategory) {
		this.cifCategory = cifCategory;
	}

	public String getAccNum() {
		return accNum;
	}

	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}

	public String getIndicator4() {
		return indicator4;
	}

	public void setIndicator4(String indicator4) {
		this.indicator4 = indicator4;
	}
}