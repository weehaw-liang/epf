//package my.gov.kwsp.helloworld.common.hazelcast;
//
//import java.util.Map;
//
//import my.gov.kwsp.helloworld.common.hazelcast.bean.MemberProfile;
//
//public interface HazelcastMemberProfileService extends BaseHazelcastService<String, MemberProfile> {
//
//	public void clearByEpfNo(String key);
//
//	public Map<String, Object> getByAccessToken(String key);
//
//	public Map<String, Object> getByRefreshToken(String key);
//
//}