package my.gov.kwsp.helloworld.common.config;

import java.util.Locale;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ResourceUtils;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableWebMvc
public class WebConfig implements WebMvcConfigurer {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {

		registry.addResourceHandler("/assets/**", "/email/**", "/receipt/**", "/iAkaun/**", "/webjars/**",
				"swagger-ui.html")
				.addResourceLocations(ResourceUtils.CLASSPATH_URL_PREFIX + "/assets/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/email/", ResourceUtils.CLASSPATH_URL_PREFIX + "/iAkaun/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/receipt/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/assets/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/email/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/receipt/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/iAkaun/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/webjars/",
						ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/")
				.resourceChain(false);
	}

	@Bean
	public InternalResourceViewResolver viewResolver() {
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setSuffix(".html");
		return resolver;
	}

	@Bean
	public LocaleResolver localeResolver() {
		SessionLocaleResolver slr = new SessionLocaleResolver();
		slr.setDefaultLocale(Locale.US);
		return slr;
	}

	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
		LocaleChangeInterceptor lci = new LocaleChangeInterceptor();
		lci.setParamName("lang");
		return lci;
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(localeChangeInterceptor());
	}
}
