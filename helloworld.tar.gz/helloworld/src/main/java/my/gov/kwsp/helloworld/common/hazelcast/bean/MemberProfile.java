package my.gov.kwsp.helloworld.common.hazelcast.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class MemberProfile implements Serializable {

	private static final long serialVersionUID = 3749882349800702241L;

	private String memberId;
	private String epfNo;
	private String accountStatus;

	private String idType;
	private String cifNumber;
	private String name1;
	private String name2;
	private String dob;
	private String myKadNo;
	private String tacMobilePhone;
	private String tacMobileStatus;
	private String mobilePhone;
	private String iAkaunStatus;
	private String shariahEffectiveDate;
	private String shariahStatus;
	private String specialUserRoleCode;

	private String accountNumber;
	private String accountCifNumber;

	private String nominationStatusViewmodeAccesss;
	private String memberViewmode;
	private String statementViewmodeAccess;

	private String registrationType;
	private String accountType;
	private String cifType;

	private String email;
	private String gender;

	// TODO to be remove after the applyToken permanent solution apply
	private String username;
	private String password;

	private String accessToken;
	private String accessTokenExpiryTime;

	private String refreshToken;
	private String refreshTokenExpiryTime;

	private int tncVersion;

	private String lastLoginDateTime;

	private String smsChallengeJourneyId;

	private String tacActivationTxnId;
	private String tacActivationExpiryTime;

	private String sessionId;

}
