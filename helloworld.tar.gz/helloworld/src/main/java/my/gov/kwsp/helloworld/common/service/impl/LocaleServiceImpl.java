package my.gov.kwsp.helloworld.common.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import my.gov.kwsp.helloworld.common.bean.LocaleBean;
import my.gov.kwsp.helloworld.common.entity.Locale;
import my.gov.kwsp.helloworld.common.enumeration.LocaleCategory;
import my.gov.kwsp.helloworld.common.repository.LocaleRepo;
import my.gov.kwsp.helloworld.common.service.LocaleService;
import my.gov.kwsp.helloworld.common.util.CacheStore;

@Service
public class LocaleServiceImpl implements LocaleService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LocaleServiceImpl.class);

	@Autowired
	private LocaleRepo localeRepo;

	@Autowired
	private CacheStore<List<LocaleBean>> messageListCache;

	@Override
	public String getMessage(String lang, String code) {
		LOGGER.info("getMessage with code {}", code);

		List<LocaleBean> cachedLocaleList = getAllCachedLocaleMessageRecords();
		if (cachedLocaleList != null && !cachedLocaleList.isEmpty()) {
			for (LocaleBean cachedLocale : cachedLocaleList) {
				if (cachedLocale.getLocaleId().equals(code)) {
					if (lang.equalsIgnoreCase(java.util.Locale.US.getLanguage())) {
						return cachedLocale.getEnglishString();
					} else {
						return cachedLocale.getBahasaString();
					}
				}
			}
		}

		return null;
	}

	private List<LocaleBean> getAllCachedLocaleMessageRecords() {
		return getAllCachedLocaleMessageRecords(null);
	}

	private List<LocaleBean> getAllCachedLocaleMessageRecords(LocaleCategory category) {
		try {
			LOGGER.info("Locale Message memoryCache size - {}", messageListCache.size());

			String localeCacheName = category != null ? "locale_message_list_" + category.getCode()
					: "locale_message_list";

			List<LocaleBean> localeBeanList = messageListCache.get(localeCacheName);
			if (localeBeanList != null && !localeBeanList.isEmpty()) {
				LOGGER.info("memory cache of <{}> is not empty, direct return list from cache.", localeCacheName);
				return localeBeanList;
			} else {
				LOGGER.info("memory cache of <{}> is empty, get new list into cache now.", localeCacheName);

				localeBeanList = new ArrayList<>();

				List<Locale> localeList;
				if (category != null) {
					localeList = localeRepo.findAllbyCategoryAndDeletedFalse(category.getCode());
				} else {
					localeList = localeRepo.findAllNotDeleted();
				}

				if (localeList != null && !localeList.isEmpty()) {
					for (Locale locale : localeList) {
						localeBeanList.add(new LocaleBean(locale.getLocaleId(), locale.getEnglishString(),
								locale.getBahasaString()));
					}
				}

				messageListCache.add(localeCacheName, localeBeanList);

				return localeBeanList;
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
		}

		return null;
	}

}
