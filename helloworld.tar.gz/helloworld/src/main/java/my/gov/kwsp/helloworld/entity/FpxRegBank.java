package my.gov.kwsp.helloworld.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the FpxRegBank database table.
 * 
 */
@Entity
@Table(name = "FpxRegBank", schema = "mip")
@NamedQuery(name = "FpxRegBank.findAll", query = "SELECT b FROM FpxRegBank b")
public class FpxRegBank implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "BankCode", updatable = false, nullable = false)
	private String bankCode;

	@Column(name = "BankName")
	private String bankName;

	@Column(name = "BankDisplayName")
	private String bankDisplayName;

	@Column(name = "Sort")
	private Integer sort;

	@Column(name = "DELETED")
	private Boolean deleted;

	@Column(name = "EDITABLE")
	private Boolean editable;

	@Column(name = "VERSION")
	private Integer version;

	@Column(name = "CREATEDBY")
	private Long createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATEDDATETIME")
	private Date createdDatetime;

	@Column(name = "MODIFIEDBY")
	private Long modifiedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "MODIFIEDDATETIME")
	private Date modifiedDatetime;

	public FpxRegBank() {
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankDisplayName() {
		return bankDisplayName;
	}

	public void setBankDisplayName(String bankDisplayName) {
		this.bankDisplayName = bankDisplayName;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public Boolean getEditable() {
		return editable;
	}

	public void setEditable(Boolean editable) {
		this.editable = editable;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDatetime() {
		return createdDatetime;
	}

	public void setCreatedDatetime(Date createdDatetime) {
		this.createdDatetime = createdDatetime;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedDatetime() {
		return modifiedDatetime;
	}

	public void setModifiedDatetime(Date modifiedDatetime) {
		this.modifiedDatetime = modifiedDatetime;
	}
}