package my.gov.kwsp.helloworld.common.constant;

public class PlatformConstants {
	public static final String IOS = "IOS"; // app language
	public static final String ANDROID = "ANDROID"; // app platform
	public static final String WEB = "WEB"; // app version
	public static final String SYSTEM = "SYSTEM"; // app version
}
