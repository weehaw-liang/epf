package my.gov.kwsp.helloworld.common.bean.esb;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonMemberResponse {

	private String requestTimeStamp;
	private String responseTimeStamp;
	private String responseCode;
	private String responseMessage;
	private CommonMemberDetailReq detail;
	private ResponseError[] error;

	public CommonMemberResponse() {
	}

	public String getRequestTimeStamp() {
		return requestTimeStamp;
	}

	public void setRequestTimeStamp(String requestTimeStamp) {
		this.requestTimeStamp = requestTimeStamp;
	}

	public String getResponseTimeStamp() {
		return responseTimeStamp;
	}

	public void setResponseTimeStamp(String responseTimeStamp) {
		this.responseTimeStamp = responseTimeStamp;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public CommonMemberDetailReq getDetail() {
		return detail;
	}

	public void setDetail(CommonMemberDetailReq detail) {
		this.detail = detail;
	}

	public ResponseError[] getError() {
		return error;
	}

	public void setError(ResponseError[] error) {
		this.error = error;
	}

	public static class ResponseError {
		private String ep;
		private String code;
		private String description;

		public ResponseError() {

		}

		public String getEp() {
			return ep;
		}

		public void setEp(String ep) {
			this.ep = ep;
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}
	}
}