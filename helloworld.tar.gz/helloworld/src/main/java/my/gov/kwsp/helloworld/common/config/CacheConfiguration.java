package my.gov.kwsp.helloworld.common.config;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import my.gov.kwsp.helloworld.common.bean.LocaleBean;
import my.gov.kwsp.helloworld.common.util.CacheStore;

@Configuration
public class CacheConfiguration {

	@Value("${iakaun.mip.localeMsgEquiryInMinute}")
	private int localeMsgEquiryInMinute;

	@Bean
	public CacheStore<List<LocaleBean>> messageListCache() {
		return new CacheStore<>(localeMsgEquiryInMinute, TimeUnit.MINUTES);
	}

}
