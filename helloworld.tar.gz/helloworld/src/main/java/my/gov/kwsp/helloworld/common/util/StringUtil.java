package my.gov.kwsp.helloworld.common.util;

public class StringUtil {

	private StringUtil() {
		// prevent instantiation
	}

	/**
	 * Whether the given value is newPasswordRule.
	 */
	public static boolean isNewPasswordRule(final String str) {
		return isMatching(str, RegexUtil.NEW_PASSWORD_RULE.getRegex());
	}

	public static boolean isMatching(final String str, final String regex) {
		return StringUtil.isNotBlank(str) && regex != null && str.matches(regex);
	}

	public static boolean isNotBlank(String str) {
		return !isBlank(str);
	}

	public static boolean isBlank(String str) {
		return str == null || str.trim().isEmpty();
	}

}
