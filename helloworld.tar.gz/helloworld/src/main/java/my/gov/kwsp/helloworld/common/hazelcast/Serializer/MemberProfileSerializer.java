//package my.gov.kwsp.helloworld.common.hazelcast.Serializer;
//
//import java.io.IOException;
//
//import com.hazelcast.nio.ObjectDataInput;
//import com.hazelcast.nio.ObjectDataOutput;
//import com.hazelcast.nio.serialization.StreamSerializer;
//
//import my.gov.kwsp.helloworld.common.hazelcast.bean.MemberProfile;
//
//public class MemberProfileSerializer implements StreamSerializer<MemberProfile> {
//
//	@Override
//	public int getTypeId() {
//		return 1;
//	}
//
//	@Override
//	public void write(ObjectDataOutput out, MemberProfile object) throws IOException {
//
//		out.writeString(object.getEpfNo());
//		out.writeString(object.getAccountStatus());
//		out.writeString(object.getIdType());
//		out.writeString(object.getCifNumber());
//		out.writeString(object.getName1());
//
//		out.writeString(object.getName2());
//		out.writeString(object.getMyKadNo());
//		out.writeString(object.getTacMobilePhone());
//		out.writeString(object.getTacMobileStatus());
//		out.writeString(object.getMobilePhone());
//
//		out.writeString(object.getIAkaunStatus());
//		out.writeString(object.getShariahEffectiveDate());
//		out.writeString(object.getShariahStatus());
//		out.writeString(object.getNominationStatusViewmodeAccesss());
//		out.writeString(object.getMemberViewmode());
//
//		out.writeString(object.getStatementViewmodeAccess());
//
//		out.writeString(object.getAccountType());
//		out.writeString(object.getCifType());
//		out.writeString(object.getRegistrationType());
//		out.writeString(object.getGender());
//
//		out.writeString(object.getEmail());
//		out.writeString(object.getMemberId());
//
//		out.writeString(object.getAccountNumber());
//		out.writeString(object.getAccountCifNumber());
//
//		// TODO remove after apply Token permanent solution
//		out.writeString(object.getUsername());
//		out.writeString(object.getPassword());
//
//		out.writeString(object.getAccessToken());
//		out.writeString(object.getAccessTokenExpiryTime());
//
//		out.writeString(object.getRefreshToken());
//		out.writeString(object.getRefreshTokenExpiryTime());
//
//		out.writeInt(object.getTncVersion());
//
//		out.writeString(object.getLastLoginDateTime());
//		out.writeString(object.getSmsChallengeJourneyId());
//		out.writeString(object.getTacActivationTxnId());
//		out.writeString(object.getTacActivationExpiryTime());
//
//		out.writeString(object.getDob());
//		out.writeString(object.getSessionId());
//
//	}
//
//	@Override
//	public MemberProfile read(ObjectDataInput in) throws IOException {
//		MemberProfile profile = new MemberProfile();
//
//		profile.setEpfNo(in.readString());
//		profile.setAccountStatus(in.readString());
//		profile.setIdType(in.readString());
//		profile.setCifNumber(in.readString());
//		profile.setName1(in.readString());
//
//		profile.setName2(in.readString());
//		profile.setMyKadNo(in.readString());
//		profile.setTacMobilePhone(in.readString());
//		profile.setTacMobileStatus(in.readString());
//		profile.setMobilePhone(in.readString());
//
//		profile.setIAkaunStatus(in.readString());
//		profile.setShariahEffectiveDate(in.readString());
//		profile.setShariahStatus(in.readString());
//		profile.setNominationStatusViewmodeAccesss(in.readString());
//		profile.setMemberViewmode(in.readString());
//
//		profile.setStatementViewmodeAccess(in.readString());
//
//		profile.setAccountType(in.readString());
//		profile.setCifType(in.readString());
//		profile.setRegistrationType(in.readString());
//		profile.setGender(in.readString());
//
//		profile.setEmail(in.readString());
//		profile.setMemberId(in.readString());
//
//		profile.setAccountNumber(in.readString());
//		profile.setAccountCifNumber(in.readString());
//
//		// TODO remove after apply Token permanent solution
//		profile.setUsername(in.readString());
//		profile.setPassword(in.readString());
//
//		profile.setAccessToken(in.readString());
//		profile.setAccessTokenExpiryTime(in.readString());
//
//		profile.setRefreshToken(in.readString());
//		profile.setRefreshTokenExpiryTime(in.readString());
//
//		profile.setTncVersion(in.readInt());
//
//		profile.setLastLoginDateTime(in.readString());
//		profile.setSmsChallengeJourneyId(in.readString());
//		profile.setTacActivationTxnId(in.readString());
//		profile.setTacActivationExpiryTime(in.readString());
//
//		profile.setDob(in.readString());
//		profile.setSessionId(in.readString());
//
//		return profile;
//	}
//
//}
