package my.gov.kwsp.helloworld.service;

import my.gov.kwsp.helloworld.bean.MemberInfoReqBean;
import my.gov.kwsp.helloworld.common.bean.BaseResponse;

public interface HelloWorldService {

	public BaseResponse getFPXBankList();

	public BaseResponse getMemberDetails(MemberInfoReqBean requestBody);


}