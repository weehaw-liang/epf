package my.gov.kwsp.helloworld.common.service.mapper;

import org.springframework.stereotype.Service;

import my.gov.kwsp.helloworld.common.bean.EsbMemberResBean;
import my.gov.kwsp.helloworld.common.bean.esb.CommonMemberDetailRes;

@Service
public class MemberDetailMapper {

	public CommonMemberDetailRes getMemberDetail(final EsbMemberResBean response) {
		CommonMemberDetailRes memberDetail = new CommonMemberDetailRes();

		memberDetail.setName(response.getResponse().getDetail().getCustName());
		memberDetail.setEpfNo(response.getResponse().getDetail().getAccNum());
		memberDetail.setMyKadNo(response.getResponse().getDetail().getPrimaryIdNum());
		memberDetail.setPassportNo(response.getResponse().getDetail().getPassportNum());
		memberDetail.setBirthDate(response.getResponse().getDetail().getBirthDate());
		memberDetail.setGender(response.getResponse().getDetail().getGender());
		memberDetail.setRace(response.getResponse().getDetail().getRace());
		memberDetail.setReligion(response.getResponse().getDetail().getReligion());
		memberDetail.setMembershipStartDate(response.getResponse().getDetail().getEpfRegDate());
		memberDetail.setNationality(response.getResponse().getDetail().getCitizenCountry());
		memberDetail.setResidentStatus(response.getResponse().getDetail().getResidentStatus());
		memberDetail.setAccountClassification(response.getResponse().getDetail().getIslamicFlag());
		memberDetail.setAccountClassificationEffectiveDate(response.getResponse().getDetail().getEffectiveDate());
		memberDetail.setSchemeMembership(response.getResponse().getDetail().getIndicator4());

		return memberDetail;
	}
}
