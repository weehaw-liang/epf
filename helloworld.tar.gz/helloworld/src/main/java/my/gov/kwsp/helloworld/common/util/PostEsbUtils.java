package my.gov.kwsp.helloworld.common.util;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import my.gov.kwsp.helloworld.common.bean.EsbMemberReqBean;
import my.gov.kwsp.helloworld.common.bean.EsbMemberResBean;
import my.gov.kwsp.helloworld.common.bean.esb.CommonMemberRequest;
import my.gov.kwsp.helloworld.common.bean.esb.CommonMessageHeader;
import my.gov.kwsp.helloworld.common.service.SequenceNumberService;

public class PostEsbUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(PostEsbUtils.class);

	public static final String ESB_APP_TRANSID_SEQUENCE_NO = "MIP";

	private SequenceNumberService sequenceNumberService;

	private ObjectMapper objectMapper;
	private String requestEntityStr;
	private String esbBasicAuth;

	private EsbMemberResBean esbMemberResBean;

	private HttpStatus httpStatus;

	public PostEsbUtils() {

	}

	// getMemberDetailUtil
	public PostEsbUtils(SequenceNumberService sequenceNumberService, String esbBasicAuth, String esbApplId,
			String esbTransCode, String primaryId, String primaryIdType, String epfNo, String accountType,
			String regType, String searchType, String reqTypeCode) {
		this.sequenceNumberService = sequenceNumberService;
		this.esbBasicAuth = esbBasicAuth;
		this.objectMapper = new ObjectMapper();

		EsbMemberReqBean requestEntity = new EsbMemberReqBean();

		CommonMessageHeader headerBean = new CommonMessageHeader();
		headerBean.setVersionNo("1.0");
		headerBean.setTransCode(esbTransCode);
		headerBean.setApplId(esbApplId);
		headerBean.setApplTransId(generateApplTransId());
		headerBean.setTransDatetime(DateUtil.convertDateToString(new Date(), DateUtil.yyyy_MM_dd_HH_mm_ss_SSS));

		requestEntity.setHeader(headerBean);

		CommonMemberRequest requestBean = new CommonMemberRequest();
		requestBean.setIdNum(primaryId);
		requestBean.setIdType(primaryIdType);
		requestBean.setAccNum(epfNo);
		requestBean.setAccType(accountType);
		requestBean.setRegType(regType);
		requestBean.setSearchType(searchType);
		requestBean.setReqTypeCode(reqTypeCode);

		requestEntity.setRequest(requestBean);

		try {
			this.requestEntityStr = this.objectMapper.writeValueAsString(requestEntity);
		} catch (JsonProcessingException e) {
			LOGGER.error("Failed to convert Object to JsonString", requestEntity);
			LOGGER.error("Exception", e);
		}
	}

	// updateMemberContactInfoUtil

	private String generateApplTransId() {

//		XXX - example appl ID (Hong Leong Bank - HLB)
//		ddMMyyyy - date
//		HHmmSS - time
//		00001 - 5 digits Unique Serial Number
//		E.g: XXXddMMyyyyHHmmSS00001

		Integer nextSeq = this.sequenceNumberService.getNext(ESB_APP_TRANSID_SEQUENCE_NO);
		String seqNo = String.format("%05d", nextSeq);

		Date currentDate = new Date();
		String seqDate = DateUtil.convertDateToString(currentDate, DateUtil.ddMMyyyyHHmmss);

		StringBuilder applTransId = new StringBuilder();
		applTransId.append("EPF");
		applTransId.append(seqDate);
		applTransId.append(seqNo);

		return applTransId.toString();
	}

	public void sendPostGetMemberDetails(String esbCifDetailUrl) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		String[][] properties = createHeaders(null, null);

		HttpsClientUtil hch = new HttpsClientUtil(false);

		try {
			hch.sendPost(esbCifDetailUrl, this.requestEntityStr, properties);

			this.httpStatus = hch.getHttpStatus();

			if (this.httpStatus.value() == HttpStatus.OK.value()
					|| this.httpStatus.value() == HttpStatus.BAD_REQUEST.value()) {
				if (StringUtils.isNotBlank(hch.getResponseContent())) {
					try {

						this.esbMemberResBean = this.objectMapper.readValue(hch.getResponseContent(),
								EsbMemberResBean.class);

					} catch (Exception e2) {
						LOGGER.error("Failed to convert responseEntity - {} ", hch.getResponseContent());
						LOGGER.error("Exception", e2);
					}
				} else {
					LOGGER.error("mapper getResponseContent is empty");
				}
			} else {
				LOGGER.error("failed to trigger - responseStatus - {} ", this.httpStatus.value());
			}
		} catch (Exception e) {
			LOGGER.error("sendPostCheckMemberMaxCap hit error for URL - {} ", esbCifDetailUrl);
			LOGGER.error("Exception", e);

			this.httpStatus = hch.getHttpStatus();
		}
	}

	private String[][] createHeaders(String username, String password) {

		String auth = this.esbBasicAuth;
		String authHeader = "Basic " + auth;

		if (StringUtils.isNotBlank(username) && StringUtils.isNotBlank(password)) {
			auth = username + ":" + password;
			byte[] encodedAuth = Base64.encodeBase64(auth.getBytes());
			authHeader = "Basic " + new String(encodedAuth);
		}

		String[][] properties = { { HttpHeaders.AUTHORIZATION, authHeader } };

		return properties;
	}

	public EsbMemberResBean getEsbMemberResBean() {
		return esbMemberResBean;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
}
