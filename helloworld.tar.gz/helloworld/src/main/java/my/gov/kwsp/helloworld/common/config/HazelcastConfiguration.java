package my.gov.kwsp.helloworld.common.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.hazelcast.config.Config;
import com.hazelcast.config.JoinConfig;
import com.hazelcast.config.PartitionGroupConfig.MemberGroupType;
import com.hazelcast.config.RestApiConfig;
import com.hazelcast.config.RestEndpointGroup;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;

@Configuration
@PropertySource(value = "classpath:config.properties", ignoreResourceNotFound = true)
@PropertySource(value = "file:config.properties", ignoreResourceNotFound = true)
@PropertySource(value = "file:${external.prop}config.properties", ignoreResourceNotFound = true)
public class HazelcastConfiguration {

	private static final Logger LOGGER = LoggerFactory.getLogger(HazelcastConfiguration.class);

	@Value("${hazelcast.multicast.config}")
	private boolean multicastConfig;

	@Value("${hazelcast.kubernetes.config}")
	private boolean kubernetesConfig;

	@Value("${hazelcast.partition.group.config}")
	private boolean partitionGroupConfig;

	@Value("${hazelcast.group.name}")
	private String groupName;

	@Value("${hazelcast.service.name}")
	private String serviceName;

	@Value("${hazelcast.namespace}")
	private String nameSpace;

	@Value("${configMap.authorizations.hazelcast.timeToLiveInSeconds}")
	private int timeToLiveInSeconds;

	@Value("${configMap.authorizations.hazelcast.idleTimeInSeconds}")
	private int idleTimeInSeconds;

	@Bean
	public HazelcastInstance hazelcastInstance() {

		LOGGER.info("multicastConfig b4 hardcode: {}", this.multicastConfig);
		LOGGER.info("kubernetesConfig b4 hardcode: {}", this.kubernetesConfig);
		LOGGER.info("groupName b4 hardcode: {}", this.groupName);
		LOGGER.info("serviceName b4 hardcode: {}", this.serviceName);
		LOGGER.info("nameSpace b4 hardcode: {}", this.nameSpace);
		LOGGER.info("timeToLiveInSeconds b4 hardcode: {}", this.timeToLiveInSeconds);
		LOGGER.info("idleTimeInSeconds b4 hardcode: {}", this.idleTimeInSeconds);

		LOGGER.info("multicastConfig b4 hardcode2: {}", multicastConfig);
		LOGGER.info("kubernetesConfig b4 hardcode2: {}", kubernetesConfig);
		LOGGER.info("groupName b4 hardcode2: {}", groupName);
		LOGGER.info("serviceName b4 hardcode2: {}", serviceName);
		LOGGER.info("nameSpace b4 hardcode2: {}", nameSpace);
		LOGGER.info("timeToLiveInSeconds b4 hardcode2: {}", timeToLiveInSeconds);
		LOGGER.info("idleTimeInSeconds b4 hardcode2: {}", idleTimeInSeconds);

//		Config config = new Config();
//		config.setProperty("hazelcast.logging.type", "slf4j");
//
//		JoinConfig joinConfig = config.getNetworkConfig().getJoin();
//		joinConfig.getMulticastConfig().setEnabled(false);
//		joinConfig.getKubernetesConfig().setEnabled(true);
//
//		config.getNetworkConfig().setJoin(joinConfig);

		return Hazelcast.newHazelcastInstance(hazelcastConfig());
	}

	public Config hazelcastConfig() {
		Config config = new Config();

		config.setProperty("hazelcast.logging.type", "slf4j");

		RestApiConfig restApiConfig = config.getNetworkConfig().getRestApiConfig();
		restApiConfig.setEnabled(true).disableGroups(RestEndpointGroup.HEALTH_CHECK);

		LOGGER.info("restApiConfig enableGroups: {}", restApiConfig.getEnabledGroups());
		config.getNetworkConfig().setRestApiConfig(restApiConfig);
		config.getNetworkConfig().setReuseAddress(true);

		LOGGER.info("multicastConfig: {}", multicastConfig);
		LOGGER.info("kubernetesConfig: {}", kubernetesConfig);

		JoinConfig joinConfig = config.getNetworkConfig().getJoin();
		joinConfig.getMulticastConfig().setEnabled(multicastConfig);

		LOGGER.info("service-name: {}", serviceName);
		LOGGER.info("namespace: {}", nameSpace);

		final String serviceDns = serviceName + "." + nameSpace + ".svc.cluster.local";
		LOGGER.info("service-dns: {}", serviceDns);

//		joinConfig.getKubernetesConfig().setEnabled(kubernetesConfig).setProperty("service-dns", serviceDns)
//				.setProperty("namespace", nameSpace).setProperty("service-name", groupName);
		joinConfig.getKubernetesConfig().setEnabled(kubernetesConfig)
//				.setProperty("service-dns", serviceDns)
				.setProperty("namespace", nameSpace)
				.setProperty("service-name", groupName);

		joinConfig.getKubernetesConfig().setProperty("service-dns-timeout", "3000");

		if (partitionGroupConfig) {
			config.getPartitionGroupConfig().setEnabled(true).setGroupType(MemberGroupType.NODE_AWARE);
		}

//		config.getNetworkConfig().setJoin(joinConfig).setPort(5701).setPortAutoIncrement(true).setPortCount(20);
		config.getNetworkConfig().setJoin(joinConfig).setPort(5701);

//		config.addMapConfig(mapConfig());
//		config.getSerializationConfig().addSerializerConfig(serializerConfig());
		return config;
	}

}
