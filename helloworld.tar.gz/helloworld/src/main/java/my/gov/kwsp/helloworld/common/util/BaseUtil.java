package my.gov.kwsp.helloworld.common.util;

import java.security.SecureRandom;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import my.gov.kwsp.helloworld.common.bean.BaseResponse;
import my.gov.kwsp.helloworld.common.constant.GlobalConstants;
import my.gov.kwsp.helloworld.common.exception.ExceptionCode;
import my.gov.kwsp.helloworld.common.service.LocaleService;

@Component
public class BaseUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseUtil.class);

	private static LocaleService localeService;

	@Autowired
	public BaseUtil(LocaleService localeService) {
		BaseUtil.localeService = localeService;
	}

	public static String randomString() {
		LOGGER.info("randomString called.");

		SecureRandom rand = new SecureRandom();
		char[] choices = ("abcdefghijklmnopqrstuvwxyz" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "01234567890").toCharArray();

		StringBuilder randomString = new StringBuilder(15);
		for (int i = 0; i < 8; ++i)
			randomString.append(choices[rand.nextInt(choices.length)]);

		return randomString.toString();
	}

	public static Integer randomNumber() {
		return randomNumber(0);
	}

	public static Integer randomNumber(int size) {
		LOGGER.info("randomNumber called.");

		SecureRandom rand = new SecureRandom();

		String padded = "999999";

		if (size > 0) {
			int number = 9;
			padded = StringUtils.leftPad("", size, String.valueOf(number));
		}

		Integer upperbound = Integer.parseInt(padded);

		// generate random values from 0-999999
		return rand.nextInt(upperbound);

	}

	public static BaseResponse responseWithAuthToken(HttpServletRequest request, BaseResponse response, String language) {
		LOGGER.info("responseWithAuthToken called.");

		ExceptionCode exceptionCode = ExceptionCode.getEnum(response.getResultCode());
		if (exceptionCode != null) {
			if (!response.getResultCode().equals(ExceptionCode.NO_ERROR.code())) {
				if (localeService != null) {
					try {
						String resultMessage = localeService.getMessage(language, response.getResultCode());
						if (StringUtils.isNotBlank(resultMessage)) {
							response.setResultMessage(resultMessage);
						}
					} catch (Exception e) {
						LOGGER.error("hit error when trying to map error code message.");
						LOGGER.error("Exception", e);
					}
				}
			}
		}

		if (request.getSession().getAttribute(GlobalConstants.ACCESS_TOKEN) != null) {
			String authToken = (String) request.getSession().getAttribute(GlobalConstants.ACCESS_TOKEN);

			response.addData(GlobalConstants.ACCESS_TOKEN, authToken);

			request.getSession().removeAttribute(GlobalConstants.ACCESS_TOKEN);
		}

		LOGGER.info("BaseResponse - {}", printJson(response));

		return response;
	}

	public static String printJson(Object object) {
		try {
			if (object != null) {
				ObjectMapper mapper = new ObjectMapper();
				return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
			}
		} catch (JsonProcessingException e) {
			LOGGER.error("JsonProcessingException", e);
		} catch (Exception e) {
			LOGGER.error("Exception", e);
		}

		return null;
	}

	public static String getFullEpfNo(String epfNo) {
		return StringUtils.leftPad(epfNo, 8, "0");
	}

	public static String padHostString(String string, int length) {
		if (string == null) {
			string = "";
		}
		StringBuffer zero = new StringBuffer();
		for (int i = 0; i < length; i++) {
			zero.append(" ");
		}

		if (length >= string.length()) {
			return string + zero.substring(0, length - string.length());
		} else {
			return string.substring(0, length);
		}
	}

	public static String padHostNumeric(long number, int length) {
		return padHostNumeric(String.valueOf(number), length);
	}

	public static String padHostNumeric(String number, int length) {
		Long lnNumber = 0l;
		try {
			lnNumber = Long.parseLong(number);
		} catch (NumberFormatException ignore) {
			// do no thing...
		}

		String numberStr = String.valueOf(lnNumber);
		StringBuffer zero = new StringBuffer();
		for (int i = 0; i < length; i++) {
			zero.append("0");
		}

		if (length >= numberStr.length()) {
			return zero.substring(0, length - numberStr.length()) + numberStr;
		} else {
			return numberStr.substring(0, length);
		}
	}
}
