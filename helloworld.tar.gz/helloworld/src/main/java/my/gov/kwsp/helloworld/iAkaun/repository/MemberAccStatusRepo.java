package my.gov.kwsp.helloworld.iAkaun.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import my.gov.kwsp.helloworld.iAkaun.entity.UpdateAccStatus;

@Repository
public interface MemberAccStatusRepo extends JpaRepository<UpdateAccStatus, Long> {

	@Query("SELECT m.epfAccNo FROM UpdateAccStatus m " + " WHERE m.userId = :userId ")
	String findByMemberUserId(@Param("userId") String userId);
}