package my.gov.kwsp.helloworld.common.service;

public interface SequenceNumberService {

	public Integer getNext(String seqCode);

}
